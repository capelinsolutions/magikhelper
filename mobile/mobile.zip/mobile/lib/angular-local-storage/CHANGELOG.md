<a name="0.1.1"></a>
# 0.1.1 (2014-10-06)


## Breaking Changes

- update your `index.html` file to reference angular-local-storage at its new
  path inside the `dist` directory `/angular-local-storage/dist/angular-local-storage.js`