(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var UserConfirmationController = function($scope, $state, $ionicViewSwitcher, $ionicHistory) {
        $scope.login = function() {
            $ionicHistory.nextViewOptions({
                disableBack: true,
                historyRoot: true
            });
            $ionicViewSwitcher.nextDirection('back');
            $state.go('fol.home');
        };
    };
    module.controller('UserConfirmationController', [
        '$scope',
        '$state',
        '$ionicViewSwitcher',
        '$ionicHistory',
        UserConfirmationController
    ]);
}());
