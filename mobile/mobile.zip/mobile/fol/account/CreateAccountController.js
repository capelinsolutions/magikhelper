(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var CreateAccountController = function($filter, $ionicHistory, $scope, $rootScope, $ionicModal, $state, $stateParams, createAccountService) {
        $scope.user = {};
        $scope.user.challengequestion = 'CAC_CHQ_CITY_BORN';
        $scope.user.usertype = '0';
        $scope.firstname = '';
        $scope.lastname = '';
        $scope.user.phoneextension = '';
        $scope.searchBy = 'name';
        $scope.searchQuery = '';
        $scope.errorMsg = '';
        $scope.valueinpercent = '0';
        var onSuccess = function(response) {
            var data = response.data;
            $rootScope.username = $scope.user.username;
            $rootScope.password = $scope.user.password;
            if (data.hasError === 'false') {
                $scope.errorMsg = '';
                $rootScope.emailAddress = $scope.user.emailaddress;
                $ionicHistory.nextViewOptions({
                    disableBack: true,
                    historyRoot: true
                });
                $state.go('fol.user-confirmation');
            } else if (data.hasError === 'true') {
                $scope.errorMsg = data.errorMgs;
            }
        };
        var onError = function(data) {
            if (data.status === 401 || data.status === 404 || data.status === 400 || data.status === 500) {
                $scope.errorMsg = 'Internal error, try again later.';
            } else {
                $scope.errorMsg = data.errorMgs;
            }
        };
        $scope.doCreateAccount = function() {
            $scope.user.customerId = $stateParams.customerNumber;
            if ($scope.user.phoneextension === null) {
                $scope.user.phoneextension = '';
            }
            // making copy of user object as chellenge question needs to be translated 
            var user = angular.copy($scope.user);
            user.challengequestion = $filter('translate')(user.challengequestion);
            createAccountService.createAccount(user).then(onSuccess, onError);
        };
        $scope.challengequestions = [
            'CAC_CHQ_CITY_BORN',
            'CAC_CHQ_PET_NAME',
            'CAC_CHQ_FAVORITE_SPORT',
            'CAC_CHQ_SPORT_TEAM',
            'CAC_CHQ_YEAR_FATHER_BORN',
            'CAC_CHQ_SIBLING_CITY',
            'CAC_CHQ_SPOUSE_CITY',
            'CAC_CHQ_WEDDING_PLACE',
            'CAC_CHQ_BEST_FRIEND_NAME'
        ];
        $scope.doSomething = function(item) {
            $scope.modalData.msg = item;
            $scope.modal.hide();
        };
        $scope.updateErrorMsg = function() {
            $scope.errorMsg = '';
        };
        $scope.setFieldDirty = function(field) {
            field.$setDirty();
        };
        $ionicModal.fromTemplateUrl('fol/account/challengequestion-modal.tpl.html', { scope: $scope }).then(function(modal) {
            $scope.modal = modal;
        });
        
        $ionicModal.fromTemplateUrl('fol/account/terms-and-condition.tpl.html', { scope: $scope }).then(function(modal) {
            $scope.termsModal = modal;
        });
        
    };
    module.controller('CreateAccountController', [
        '$filter',
        '$ionicHistory',
        '$scope',
        '$rootScope',
        '$ionicModal',
        '$state',
        '$stateParams',
        'createAccountService',
        CreateAccountController
    ]);
}());
