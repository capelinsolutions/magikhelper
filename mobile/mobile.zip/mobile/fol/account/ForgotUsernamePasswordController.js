(function() {
    'use strict';
    var ForgotUserNamePasswordController = function($scope, $state, $stateParams, $ionicHistory, $ionicViewSwitcher, $ionicSideMenuDelegate, forgotUsernamePasswordService) {
        $scope.type = $stateParams.type;
        $scope.user = {};
        $scope.reference = $stateParams.reference;
        var onSuccess = function(response) {
            $scope.errorMsg = '';
            console.log('response:', response.data);
            $state.go('fol.forgot-username-password-result', {
                'type': $scope.type,
                'reference': $scope.user.username !== undefined ? $scope.user.username : $scope.user.emailAddress
            });
        };
        var onError = function(data) {
            if (data.status === 401 || data.status === 404 || data.status === 400 || data.status === 500) {
                $scope.errorMsg = 'Internal error, try again later.';
            } else {
                // TODO :: read the eror from server
                $scope.errorMsg = 'Username / Email address was incorrect';
            }
        };
        $scope.submit = function() {
            if ($scope.user.emailAddress) {
                //TODO : call forgot username service
                forgotUsernamePasswordService.getUsername($scope.user.emailAddress).then(onSuccess, onError);
            } else {
                //TODO : call forgot password service
                forgotUsernamePasswordService.getPassword($scope.user.username).then(onSuccess, onError);
            }    //temporary redirection
                 //            onSuccess();
        };
        $scope.login = function() {
            $ionicHistory.nextViewOptions({
                disableBack: true,
                historyRoot: true
            });
            $ionicViewSwitcher.nextDirection('back');
            $ionicSideMenuDelegate.canDragContent(false);
            $state.go('fol.home');
        };
    };
    var module = angular.module('fol.mobile');
    module.controller('ForgotUserNamePasswordController', [
        '$scope',
        '$state',
        '$stateParams',
        '$ionicHistory',
        '$ionicViewSwitcher',
        '$ionicSideMenuDelegate',
        'forgotUsernamePasswordService',
        ForgotUserNamePasswordController
    ]);
}());
