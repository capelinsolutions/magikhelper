(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.controller('productsSearchResultController', function ($scope, $state, $stateParams, $translate, productService, productList, itemListSortFactory) {
        $scope.folSearchCallback = function (searchQuery) {
            $state.go('fol.product-search', {
                showId: $stateParams.showId,
                query: searchQuery
            });
        };

        $scope.productList = productList;

        $scope.listClickedCallbackListener = function (product) {
            console.log("in controller, product, ", product);
            $state.go('fol.product-details', {
                showId: $stateParams.showId,
                categoryId: product.categoryID,
                subCategoryId: product.subCategoryID,
                productId: product.productID,
                edit: false
            });
        };

        $scope.sortOptions = [
            itemListSortFactory.sortCallbackCreator('SORT_PRICE', 'price', $scope.sortOptions),
            itemListSortFactory.sortCallbackCreator('SORT_NAME', 'title', $scope.sortOptions)
        ];
    });
}());
