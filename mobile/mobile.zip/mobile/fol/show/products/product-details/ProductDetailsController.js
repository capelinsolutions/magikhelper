(function () {
    "use strict";

    var module = angular.module("fol.mobile");

    module.controller('productDetailsController', function ($scope, $state, $stateParams, product, cartItem, cartService) {
        $scope.title = product.title;
        console.log("edit is value: %s, type of %s, ", $stateParams.edit, typeof($stateParams.edit));
        $scope.edit = $stateParams.edit === 'true';
        console.log("edit is value: %s, type of %s, ", $scope.edit, typeof($scope.edit));

        $scope.productImages = product.logos;

        $scope.productPricing = {
            discountPrice: product.discountPrice,
            discountDate: product.discountDate,
            price: product.price,
            description: product.description,
            dimension: product.dimension,
            extendedDescription: product.extendedDescription,
            uom: product.uom,
            skus: product.skus
        };

        if($scope.edit){
            addCartDetailsToProductPricing();
        }

        function addCartDetailsToProductPricing(){
            $scope.productPricing.quantity = cartItem.quantity;
            $scope.productPricing.skuID = cartItem.skuID;
        }

        function updateCartProduct(cartProduct) {
            cartProduct.categoryID = $stateParams.categoryId;
            cartProduct.subCategoryID = $stateParams.subCategoryId;
            cartProduct.productID = $stateParams.productId;
            cartProduct.title = product.title;
            cartProduct.price = product.price;
            cartProduct.logoURL = product.logos[0].imageURL;
            return cartProduct;
        }

        $scope.addProduct = function(cartProduct) {
            cartProduct = updateCartProduct(cartProduct);
            cartService.addToCart($stateParams.showId, cartProduct);
        };

        $scope.removeProduct = function(){
            cartService.removeFromCart($stateParams.showId, $stateParams.productId, $stateParams.sku);
        };

        $scope.editProduct = function(cartProduct){
            cartProduct = updateCartProduct(cartProduct);
            cartService.updateCart($stateParams.showId, cartProduct, $stateParams.sku);
        };

    });
}());
