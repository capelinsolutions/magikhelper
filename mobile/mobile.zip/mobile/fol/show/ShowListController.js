(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var ShowListController = function($scope) {
        $scope.title = '';
    };
    module.controller('ShowListController', [
        '$scope',
        ShowListController
    ]);
}());
