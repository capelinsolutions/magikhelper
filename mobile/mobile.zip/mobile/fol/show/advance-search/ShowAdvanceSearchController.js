(function() {
    "use strict";

    var module = angular.module("fol.mobile");

    var ShowAdvanceSearchController = function($scope, $state, $stateParams, shows) {

        console.log("shows:", shows);
        $scope.shows = shows;
        $scope.doSearch = function(params){
            
            //removing entries which user dont want to use in search
            _.each(params, function(value, key){
                if (value === "" || value === null){
                    delete params[key];
                }
            });
            $state.go('fol.advanced-search', {searchQuery: JSON.stringify(params), isAdvance: true});
        };
    };

    module.controller("ShowAdvanceSearchController", ["$scope", "$state", "$stateParams", "shows", ShowAdvanceSearchController]);

}());
