(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var BoothInfoController = function($scope, $state, $stateParams, boothInfo, showInfo) {
        $scope.descriptionText = boothInfo.boothDescription;
        $scope.boothEquipment = {
            aisleCarpetText: boothInfo.aiseltitle,
            aisleCarpetColor: boothInfo.aisleColor,
            backDrapeText: boothInfo.drapBlackTitle,
            backDrapeColor: boothInfo.drapBlackColor,
            sideDrapeText: boothInfo.sideTitle,
            sideDrapeColor: boothInfo.sideColor
        };
        $scope.showStage = showInfo.stage;
    };
    module.controller('BoothInfoController', [
        '$scope',
        '$state',
        '$stateParams',
        'boothInfo',
        'showInfo',
        BoothInfoController
    ]);
}());
