(function(){
	"use strict";
	var ShowViewAllController = function($scope, $stateParams, shows) {
		$scope.shows = shows;
        if ($stateParams.type === "1") {
    		$scope.title="Upcoming Shows List";
    	}
    	// view all past shows
    	else if ($stateParams.type === "2"){
    		$scope.title="Past Shows List";
    	}
	};
	
	var module = angular.module("fol.mobile");
	module.controller('ShowViewAllController', ["$scope", "$stateParams", "shows", ShowViewAllController]);
	
}());