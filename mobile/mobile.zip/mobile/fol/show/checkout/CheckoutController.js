(function () {
    "use strict";
    var module = angular.module("fol.mobile");

    module.controller('CheckoutController', 
        function (
            $scope, 
            $stateParams,
            $filter,
            addressService, 
            boothsList, 
            showDetail, 
            currentUser, 
            currentUserCompany, 
            countryList, 
            stateList, 
            checkoutService,
            cartItems
        ){

        // constants for pay methods
        var payMethod = {
            NONE: 'NONE',
            CREDIT_CARD: 'CREDIT-CARD',
            BOTH: 'BOTH',
            THIRD_PARTY_WITH_NO_BOOTHS: 'THIRD-PARTY-WITH-NO-BOOTHS'
        };

        var defaultPaymentType = 'Credit';
        if (showDetail.payMethod == payMethod.BOTH) {
            defaultPaymentType = 'Invoice';
        };

        $scope.allowCheckout = (showDetail.payMethod == payMethod.CREDIT_CARD || showDetail.payMethod == payMethod.BOTH);

        var defaultCountryArr = _.filter(countryList, function(country) {
            if (currentUserCompany.country) {
                return country.countryCode === currentUserCompany.country;
            } 
            else {
                return country.countryCode === addressService.getDefaultCountry();
            }
        });
        var defaultCountry = defaultCountryArr[0];

        var defaultStateArr = _.filter(stateList, function(state) {
            if (currentUserCompany.state) {
                return state.stateName === currentUserCompany.state;
            } 
        });
        var defaultState = defaultStateArr[0];

        $scope.staticData = {
            booths: boothsList,
            countries: countryList,
            states: stateList,
            paymentTypes: [
                { text: 'SCO_PT_CREDIT', value: 'Credit', disabled: showDetail.payMethod != payMethod.CREDIT_CARD && showDetail.payMethod != payMethod.BOTH},
                { text: 'SCO_PT_INVOICE', value: 'Invoice', disabled: showDetail.payMethod != payMethod.BOTH }                
            ],
            payMethod: showDetail.payMethod
        };

        // model data that needs to be transformed before posting
        $scope.checkout = {
            booth: null,
            state: defaultState,
            country: defaultCountry,
            card_expiration_date: null
        };

        $scope.$watchCollection("checkout", function () {
            $scope.checkoutData.boothNumber = $scope.checkout.booth;
            $scope.checkoutData.billingAddress.state = $scope.checkout.state.stateName;
            $scope.checkoutData.billingAddress.country = $scope.checkout.country.countryCode;
            $scope.checkoutData.creditCardDetails.expirationYear = $filter('date')($scope.checkout.card_expiration_date, 'yyyy');
            $scope.checkoutData.creditCardDetails.expirationMonth = $filter('date')($scope.checkout.card_expiration_date, 'MM');
        });

        $scope.paymentData = cartItems.slice();

        $scope.checkoutData = {
            showID: $stateParams.showId,
            boothNumber: null,
            boothWidth: null,
            boothHeight: null,
            invoiceEmail: currentUser.email,
            referenceNumber: null,
            billingAddress: {
                firstName: currentUser.firstName,
                lastName: currentUser.lastName,
                addressLine1: currentUserCompany.addressLine1,
                addressLine2: currentUserCompany.addressLine2,
                city: currentUserCompany.city,
                state: null,
                zip: currentUserCompany.zip,
                country: null
            },
            paymentMethod: defaultPaymentType,
            creditCardDetails: {
                firstName: currentUser.firstName,
                lastName: currentUser.lastName,
                cardNumber: null,
                expirationYear: null,
                expirationMonth: null
            },
            items: $scope.paymentData,
            isAccepted: true
        };

        $scope.selectCountry = function() {
            addressService.getStates($scope.checkout.country_code.countryCode).then(function(states) {
                $scope.staticData.states = states;
            });
        };

        $scope.doCheckout = function() {
            checkoutService.postCheckout($stateParams.showId, $scope.checkoutData).then(function(data) {
            });
        };

    });
}());