(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var ShowInformationController = function($scope, $state, $stateParams) {
        $scope.showId = $stateParams.showId;
    };
    module.controller('ShowInformationController', [
        '$scope',
        '$state',
        '$stateParams',
        ShowInformationController
    ]);
}());
