(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var ContactInformationController = function($scope, $stateParams, contactsService, CONTACT_US_DEFAULT_EMAIL, CONTACT_US_DEFAULT_PHONE, stage) {
        $scope.stage = stage;
        var onSuccess = function(response) {
            $scope.contacts = response.contacts;
        };
        var onFreemanContactSuccess = function(response) {
            $scope.freemanContact = response;
        };
        var onShippingContactSuccess = function(response) {
            $scope.shippingContact = response;
        };
        var onFreemanAudioVisualContactSuccess = function(response) {
            console.log('response:', response);
            $scope.freemanAudioVisualContact = response;
        };
        var onError = function(data) {
            // TODO :: handle error
            console.log('error occurred', data);
        };
        // TODO :: Move these to the resolve promise
        contactsService.getContact($stateParams.showId).then(onSuccess, onError);
        contactsService.getFreemanContact($stateParams.showId).then(onFreemanContactSuccess, onError);
        contactsService.getShippingContact($stateParams.showId).then(onShippingContactSuccess, onError);
        contactsService.getFreemanAudioVisualContact($stateParams.showId).then(onFreemanAudioVisualContactSuccess, onError);
        $scope.customerInfo = {
            customerInfoEmail: CONTACT_US_DEFAULT_EMAIL,
            customerInfoPhone: CONTACT_US_DEFAULT_PHONE
        };
    };
    module.controller('ContactInformationController', [
        '$scope',
        '$stateParams',
        'contactsService',
        'CONTACT_US_DEFAULT_EMAIL',
        'CONTACT_US_DEFAULT_PHONE',
        'stage',
        ContactInformationController
    ]);
}());
