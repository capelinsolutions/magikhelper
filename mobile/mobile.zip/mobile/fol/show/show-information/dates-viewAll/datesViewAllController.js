(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var datesViewAllController = function($scope, showDates, showDetail) {
        $scope.title = '';
        $scope.allEvents = showDates;
        $scope.showStatus = showDetail.stage;
    };
    module.controller('datesViewAllController', [
        '$scope',
        'showDates',
        'showDetail',
        datesViewAllController
    ]);
}());
