(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.controller('CENotificationDetailController', function ($scope, notification) {
        
        if(notification && notification.issueStatus ){
            $scope.description = notification.description;
            $scope.booth = notification.boothNumber;
            $scope.contact = notification.contactName;
            $scope.status = notification.issueStatus;
            $scope.submitted = notification.createdDate;
            if(notification.comments){
                //TODO :" check for cancelled status then show the comments
                scope.commentsTitle = "CER_COMMENTS";
                $scope.comments = notification.comments;
            }
            $scope.title = "CER_DETAIL_TITLE";
        }
        else if(notification){
            $scope.title = "CEA_DETAIL_TITLE";
            $scope.description = notification.alertTitle ;
            $scope.booth = notification.boothNumber;
            $scope.date = notification.createdDate;
            if(notification.description){
                $scope.commentsTitle = "CEA_DESCRIPTION_TITLE";
                $scope.comments = notification.description;
                console.log($scope.comments);
            }
        }
    });
})();
