(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.controller('CEAddRequestController', function ($scope, $stateParams, $ionicHistory, boothsList, user, requestText, ceService)     {
        
        $scope.request={};
        $scope.request.Description = requestText;
        $scope.request.ContactName = user.firstName +" " + user.lastName ;
        $scope.request.MobileNumber = user.phone;
        $scope.booths=boothsList;
        //Make default selection
        if(boothsList.length > 0){
            $scope.request.BoothNumber =  boothsList[0].boothNumber;
        }
        $scope.onSubmit = function(){
            // as server accept 0 or 1 value
            $scope.request.NotifyViaText = $scope.request.notify ? 1 : 0;
            console.log("$scope.request:",$scope.request);
            
            ceService.addRequest($stateParams.showId, $scope.request).then(function(response){
                if(response.createIssueResult){
                    alert('Request has been created successfully');
                }
            },
            function(err){
                console.log("err:", err);
                alert('Error occurred while adding request.');
            });
        };
        
        $scope.back = function() {
            $ionicHistory.goBack();
        };
    });
})();
