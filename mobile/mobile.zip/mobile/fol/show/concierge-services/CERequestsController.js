(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.controller('CERequestsController', function ($scope, $state, $stateParams, requests, showDetail) {
        
        $scope.requests = requests;
        $scope.request = {};
        
        $scope.addNewRequest = function(){
            $state.go('fol.ce-request-add', {showId : $stateParams.showId, requestText: JSON.stringify($scope.request.requestText)});
        };
        
        $scope.showRequestsList = function(){
            $state.go('fol.ce-requests-list', {showId : $stateParams.showId});
        };
        
        function configureContactUsCard(){
            $scope.folContactUs = {
                showSitePhone: showDetail.showSitePhone,
                showState: showDetail.state,
                showName: showDetail.name,
                showCity: showDetail.city,
                showStage: showDetail.stage
            };
        }
        configureContactUsCard();
    });
})();
