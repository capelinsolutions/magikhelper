(function () {
    "use strict";

    var module = angular.module("fol.mobile");

    var ConciergeServicesController = function ($scope, showDetail){
        
        function configureContactUsCard(){
            $scope.folContactUs = {
                showSitePhone: showDetail.showSitePhone,
                showState: showDetail.state,
                showName: showDetail.name,
                showCity: showDetail.city,
                showStage: showDetail.stage
            };
        }
        
        configureContactUsCard();
    };

    module.controller("ConciergeServicesController", ["$scope", "showDetail", ConciergeServicesController]);

}());

