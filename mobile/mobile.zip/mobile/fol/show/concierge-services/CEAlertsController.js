(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.controller('CEAlertsController', function ($scope, $stateParams, alerts) {
        
        $scope.alerts = alerts;
        $scope.filter = 1;
    });
})();
