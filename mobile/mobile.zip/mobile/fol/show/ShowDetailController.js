(function () {
    "use strict";

    var module = angular.module("fol.mobile");

    module.controller("ShowDetailController", function ($scope, $state, $stateParams, $rootScope, $filter, boothInfo, venueAddress, showDates, showDetail, cartService) {
        $scope.showDetail = showDetail;
        $scope.title = "Show Detail";
        $scope.showId = $stateParams.showId;

        configureTasks();
        configureHeaderCard();
        configureLocationCard();
        configureImportantDatesCard();
        getSurvey();
        configureContactUsCard();
        configureDevTasks();

        $scope.boothDescription = boothInfo.boothDescription;

        $scope.navigateToBoothInfo = function () {
            $state.go('fol.booth-info', {showId: $stateParams.showId});
        };

        $scope.navigateToEventsDate = function () {
            $scope.viewAll = true;
            $state.go('fol.important-dates', {showId: $stateParams.showId});

        };

        function configureContactUsCard() {
            $scope.folContactUs = {
                showSitePhone: showDetail.showSitePhone,
                showState: showDetail.state,
                showName: showDetail.name,
                showCity: showDetail.city,
                showStage: showDetail.stage
            };
        }

        function configureHeaderCard() {
            $scope.showDetail = showDetail;
            var showDates = "";
            var startDate = new Date(Date.parse($scope.showDetail.openDate));
            var endDate = new Date(Date.parse($scope.showDetail.closeDate));
            var startMonth = startDate.getMonth() + 1;
            var endMonth = endDate.getMonth() + 1;
            if (startMonth === endMonth) {
                showDates = $filter('date')(startDate, 'MMM dd') + ' - ' + $filter('date')(endDate, 'dd') + ', ' + $filter('date')(startDate, 'yyyy');
            }
            else {
                showDates = $filter('date')(startDate, 'MMM dd') + ' - ' + $filter('date')(endDate, 'MMM dd') + ', ' + $filter('date')(startDate, 'yyyy');
            }
            $scope.showDetail.showDates = showDates;
            $scope.showDetail.untilOpen = moment(startDate).fromNow(true) + ' until open';
        }

        function configureLocationCard() {
            $scope.address = {};
            $scope.address = {
                contactName: venueAddress.contactName,
                addressLine1: venueAddress.addressLine1,
                addressLine2: venueAddress.addressLine2,
                city: venueAddress.city,
                state: venueAddress.state,
                zipCode: venueAddress.zipCode,
                phone: venueAddress.phone,
                email: venueAddress.email
            };
        }

        function configureDevTasks() {
            $scope.devTasks = [];

            $scope.devTasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Product Search",
                    task: function () {
                        $state.go('fol.product-search', {showId: $stateParams.showId});
                    }
                }
            );

            $scope.devTasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Cart",
                    task: function () {
                        $state.go('fol.cart', {showId: $stateParams.showId});
                    }
                }
            );

            $scope.devTasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Checkout",
                    task: function () {
                        $state.go('fol.checkout', {showId: $stateParams.showId});
                    }
                }
            );

            $scope.devTasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Concierge Services",
                    task: function () {
                        $state.go('fol.concierge-services', {showId: $stateParams.showId});
                    }
                }
            );

            $scope.devTasks.push({
                icon: "ion-gear-a",
                text: "Clear Cart",
                task: function () {
                    cartService.clearCart($stateParams.showId);
                }
            });
        }

        function configureTasks() {

            $scope.tasks = [];

            if ($scope.showDetail.isOpenForOrders) {
                $scope.tasks.push(
                    {
                        icon: "ion-gear-a",
                        text: "Ordering",
                        task: function () {
                            $state.go('fol.under-construction');
                        }
                    }
                );
            }

            $scope.tasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Show Information",
                    task: function () {
                        $state.go('fol.show-information', {showId: $stateParams.showId});
                    }
                }
            );

            if ($scope.showDetail.isShippingEnabled) {
                $scope.tasks.push(
                    {
                        icon: "ion-gear-a",
                        text: "Freight Status",
                        task: function () {
                            $state.go('fol.under-construction');
                        }
                    }
                );
            }

            if ($scope.showDetail.isCE) {
                $scope.tasks.push(
                    {
                        icon: "ion-gear-a",
                        text: "Concierge Services",
                        task: function () {
                            $state.go('fol.concierge-services', {showId: $stateParams.showId});
                        }
                    }
                );
            }

            $scope.tasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Notifications",
                    task: function () {
                        $state.go('fol.under-construction');
                    }
                }
            );

            if ($scope.showDetail.ismhaEnabled) {
                $scope.tasks.push(
                    {
                        icon: "ion-gear-a",
                        text: "Outbound Paperwork",
                        task: function () {
                            $state.go('fol.under-construction');
                        }
                    }
                );
            }

            $scope.tasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Account Summary",
                    task: function () {
                        $state.go('fol.under-construction');
                    }
                }
            );

            if ($scope.showDetail.hasQuickFacts) {
                $scope.tasks.push(
                    {
                        icon: "ion-gear-a",
                        text: "Quick Facts",
                        task: function () {
                            $state.go('fol.under-construction');
                        }
                    }
                );
            }

            $scope.tasks.push(
                {
                    icon: "ion-gear-a",
                    text: "Forms & Brochures",
                    task: function () {
                        $state.go('fol.under-construction');
                    }
                }
            );

        }

        function configureImportantDatesCard() {
            $scope.events = [];
            $rootScope.allEvents = showDates;
            $scope.events = _.remove(showDates, function (event) {
                return event.isImportant && moment(event.enddateTime).isAfter();
            });
        }

        function getSurvey() {
            if ($scope.showDetail !== undefined && $scope.showDetail.stage === 'SHOW-OPEN') {
                var endDate = new Date(Date.parse($scope.showDetail.closeDate));
                var closeDt = moment(endDate);
                var now = moment();
                if (now.diff(closeDt) < 30) {
                    $scope.showSurvey = true;
                }
            }
        }

    });
}());
