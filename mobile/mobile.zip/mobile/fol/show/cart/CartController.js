(function () {
    "use strict";
    var module = angular.module("fol.mobile");
    module.controller('CartController', function ($stateParams, $rootScope, $scope, $state, cartItems, itemListSortFactory) {
        $scope.productList = cartItems;

        $scope.listClickedCallbackListener = function (product) {
            console.log('transition to product details page', product);
            $state.go('fol.product-details', {
                showId: $stateParams.showId,
                categoryId: product.categoryID,
                subCategoryId: product.subCategoryID,
                productId: product.productID,
                sku: product.skuID,
                edit: true
            });
        };

        $scope.checkoutCallback = function(){
            $state.go('fol.checkout', {showId: $stateParams.showId});
        };

        $scope.sortOptions = [
            itemListSortFactory.sortCallbackCreator('SORT_PRICE', 'price', $scope.sortOptions),
            itemListSortFactory.sortCallbackCreator('SORT_NAME', 'title', $scope.sortOptions)
        ];
    });
})();
