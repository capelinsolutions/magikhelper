(function() {
    'use strict';
    var FolAppController = function($scope, $state, $http, $ionicSideMenuDelegate, $ionicHistory, securityTokenService) {
        $scope.logout = function() {
            securityTokenService.logout();
            $ionicHistory.nextViewOptions({
                disableBack: true,
                disableAnimate: true,
                historyRoot: true
            });
            $ionicHistory.clearCache();
            $ionicHistory.clearHistory();
            $ionicSideMenuDelegate.toggleLeft();
            $ionicSideMenuDelegate.canDragContent(false);
            $state.go('fol.home');
        };
        $scope.isLoggedIn = securityTokenService.isLoggedIn();
        $scope.$on('UserLoginStatus', function(event, status) {
            $scope.isLoggedIn = status;
        });
    };
    var module = angular.module('fol.mobile');
    module.controller('FolAppController', [
        '$scope',
        '$state',
        '$http',
        '$ionicSideMenuDelegate',
        '$ionicHistory',
        'securityTokenService',
        FolAppController
    ]);
}());
