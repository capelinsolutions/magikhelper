(function() {
    'use strict';
    var SearchCompanyController = function($rootScope, $scope, $state, searchCompanyService, $filter) {
        var onSuccess = function(response) {
            $scope.errorMsg = '';
            $rootScope.companyList = response;
            $state.go('fol.search-company-result', { 'searchQuery': $scope.searchQuery });
        };
        var onError = function(data) {
            if (data.status === 401 || data.status === 404 || data.status === 400 || data.status === 500) {
                $scope.errorMsg = 'Internal error, try again later.';
            }
        };
        $scope.doCompanySearch = function() {
            var searchStr = $scope.searchQuery;
            if (searchStr.indexOf('&#') !== -1) {
                searchStr = searchStr.substring(0, searchStr.indexOf('&#'));
                $scope.searchQuery = searchStr;
            }
            var encodedfilter = $filter('encodeURIComponent')(searchStr);
            encodedfilter = encodedfilter.replace('%2F', '%252F');
            encodedfilter = encodedfilter.replace('%5C', '%255C');
            searchCompanyService.getCompaniesByName(encodedfilter).then(onSuccess, onError);
        };
    };
    var module = angular.module('fol.mobile');
    module.controller('SearchCompanyController', [
        '$rootScope',
        '$scope',
        '$state',
        'searchCompanyService',
        '$filter',
        SearchCompanyController
    ]);
}());
