(function() {
    'use strict';
    var SearchCompanyResultsController = function($rootScope, $scope, $state, $stateParams, $timeout, $ionicHistory) {
        $scope.companies = [];
        $scope.haveMore = false;
        var chunkSize = 10;
        var currentRowCount = 0;
        $scope.searchQuery = $stateParams.searchQuery;
        $scope.companyId = $stateParams.companyId;
        $scope.totalRowsCount = $rootScope.companyList.length;
        var addItems = function() {
            if (currentRowCount + chunkSize <= $scope.totalRowsCount) {
                console.log('1');
                $scope.companies = $scope.companies.concat($rootScope.companyList.splice(0, chunkSize));
                currentRowCount += chunkSize;
                $scope.$broadcast('scroll.infiniteScrollComplete');
            } else {
                if ($scope.totalRowsCount > 0 && $scope.companies.length < $scope.totalRowsCount) {
                    console.log('2');
                    $scope.companies = $scope.companies.concat($rootScope.companyList);
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }
                $scope.haveMore = false;
            }
        };
        $scope.back = function() {
            $ionicHistory.goBack();
        };
        $scope.loadMore = function() {
            // Added Loader Delay
            $timeout(function() {
                addItems();
            }, 500);
        };
        if ($rootScope.companyList.length > 0) {
            $scope.totalRowsCount = $rootScope.companyList.length;
            $scope.haveMore = $scope.totalRowsCount > chunkSize;
            addItems();
        }
    };
    var module = angular.module('fol.mobile');
    module.controller('SearchCompanyResultsController', [
        '$rootScope',
        '$scope',
        '$state',
        '$stateParams',
        '$timeout',
        '$ionicHistory',
        SearchCompanyResultsController
    ]);
}());
