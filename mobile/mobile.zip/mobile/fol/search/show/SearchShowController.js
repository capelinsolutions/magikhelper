(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var SearchShowController = function($filter, $scope, $state, searchShowService) {
        $scope.searchBy = 'name';
        $scope.searchQuery = '';
        $scope.searchBooth = '';
        $scope.errorMsg = '';
        var showList = [];
        var searchStr = '';
        var boothStr = '';
        var onSuccess = function(response) {
            $scope.errorMsg = '';
            showList = response;
            console.log('showlist', showList);
            searchShowService.setShowsList(showList);
            if ($scope.searchBooth.length > 0) {
                $state.go('fol.search-show-with-booth-result', {
                    'searchBy': $scope.searchBy,
                    'searchQuery': $scope.searchQuery,
                    'searchBooth': $scope.searchBooth
                });
            } else {
                $state.go('fol.search', {
                    'searchBy': $scope.searchBy,
                    'searchQuery': $scope.searchQuery
                });
            }
        };
        var onError = function(data) {
            if (data.status === 401 || data.status === 404 || data.status === 400 || data.status === 500) {
                $scope.errorMsg = 'Internal error, try again later.';
            }
        };
        $scope.doSearch = function() {
            searchStr = $scope.searchQuery;
            if (searchStr.indexOf('&#') !== -1) {
                searchStr = searchStr.substring(0, searchStr.indexOf('&#'));
                $scope.searchQuery = searchStr;
            }
            var encodedfilter = $filter('encodeURIComponent')(searchStr);
            encodedfilter = encodedfilter.replace('%2F', '%252F');
            encodedfilter = encodedfilter.replace('%5C', '%255C');
            if ($scope.searchBy === 'name') {
                searchShowService.getShowName(encodedfilter).then(onSuccess, onError);
            } else if ($scope.searchBy === 'acronym') {
                searchShowService.getShowAcronym(encodedfilter).then(onSuccess, onError);
            }
        };
        $scope.doSearchWithBooth = function() {
            searchStr = $scope.searchQuery;
            boothStr = $scope.searchBooth;
            if (searchStr.indexOf('&#') !== -1) {
                searchStr = searchStr.substring(0, searchStr.indexOf('&#'));
                $scope.searchQuery = searchStr;
            }
            if (boothStr.indexOf('&#') !== -1) {
                boothStr = boothStr.substring(0, boothStr.indexOf('&#'));
                $scope.searchBooth = boothStr;
            }
            var encodedShowfilter = $filter('encodeURIComponent')(searchStr);
            var encodedBoothFilter = $filter('encodeURIComponent')(boothStr);
            encodedShowfilter = encodedShowfilter.replace('%2F', '%252F');
            encodedShowfilter = encodedShowfilter.replace('%5C', '%255C');
            encodedBoothFilter = encodedBoothFilter.replace('%2F', '%252F');
            encodedBoothFilter = encodedBoothFilter.replace('%5C', '%255C');
            if ($scope.searchBy === 'name') {
                searchShowService.getShowName(encodedShowfilter, encodedBoothFilter).then(onSuccess, onError);
            } else if ($scope.searchBy === 'acronym') {
                searchShowService.getShowAcronym(encodedShowfilter, encodedBoothFilter).then(onSuccess, onError);
            }
        };
        $scope.updateErrorMsg = function() {
            $scope.errorMsg = '';
        };
    };
    module.controller('SearchShowController', [
        '$filter',
        '$scope',
        '$state',
        'searchShowService',
        SearchShowController
    ]);
}());
