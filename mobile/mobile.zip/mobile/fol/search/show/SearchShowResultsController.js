(function() {
    'use strict';
    var SearchShowResultsController = function($scope, $timeout, $stateParams, $ionicHistory, searchShowService) {
        $scope.haveMore = false;
        var chunkSize = 10;
        var currentRowCount = 0;
        $scope.totalRowsCount = 0;
        var showList;
        $scope.searchQuery = $stateParams.searchQuery;
        $scope.shows = [];
        var addItems = function() {
            console.log('additems');
            if (currentRowCount + chunkSize <= $scope.totalRowsCount) {
                console.log('1');
                $scope.shows = $scope.shows.concat(showList.splice(0, chunkSize));
                currentRowCount += chunkSize;
                $scope.$broadcast('scroll.infiniteScrollComplete');
            } else {
                if ($scope.totalRowsCount > 0 && $scope.shows.length < $scope.totalRowsCount) {
                    console.log('$scope.shows:', $scope.shows.length);
                    console.log('showList.length:', showList.length);
                    $scope.shows = $scope.shows.concat(showList);
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }
                $scope.haveMore = false;
            }
        };
        $scope.loadMore = function() {
            // Added Loader Delay
            $timeout(function() {
                addItems();
            }, 500);
        };
        $scope.back = function() {
            $ionicHistory.goBack();
        };
        if (searchShowService.getShowsList().length > 0) {
            showList = searchShowService.getShowsList();
            $scope.totalRowsCount = showList.length;
            $scope.haveMore = $scope.totalRowsCount > chunkSize;
            addItems();
        }
    };
    var module = angular.module('fol.mobile');
    module.controller('SearchShowResultsController', [
        '$scope',
        '$timeout',
        '$stateParams',
        '$ionicHistory',
        'searchShowService',
        SearchShowResultsController
    ]);
}());
