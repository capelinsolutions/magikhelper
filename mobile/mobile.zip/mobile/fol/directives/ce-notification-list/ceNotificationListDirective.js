(function () {
    'use strict';
    var module = angular.module('fol.mobile');

    module.directive('folCENotificationList', function () {
        return {
            restrict: 'E',
            scope: {
                notificationList: '=',
                isAlert : '='
            },
            replace: true,
            templateUrl: 'fol/directives/ce-notification-list/ce-notification-list.tpl.html',
            controller : function($scope, $filter, $location, $ionicScrollDelegate){
                
                 var makeMap = function(data){
                    var itemList = data;
                    var map = {};
                    _.each(itemList, function(obj){
                        var list = map[obj.boothNumber];
                        if(!list){
                            list = [];
                        }
                        list.push(obj);
                        map[obj.boothNumber] = list;
                    });
                    $scope.data = map;
                };
                makeMap($scope.notificationList);
                
                if($scope.isAlert){
                    $scope.alert = {};
                    $scope.alert.filterType = 1;
                    $scope.onFilterChange = function(value){
                        var itemList = $filter('filter')($scope.notificationList, {alertType : $scope.alert.filterType});
                            makeMap(itemList);
                    }
                    $scope.onFilterChange();
                }
                $scope.detailText = "CER_VIEW_MORE";
                $scope.showingMore = {};
                $scope.showMore = function(boothId, itemList, event){
                    if($scope.showingMore[boothId] && $scope.showingMore[boothId].showing){
                        
                        $scope.showingMore[boothId] = {showing: false, limit:3};
                        $scope.detailText = "CER_VIEW_MORE";
                        
                        $location.hash(event.target.parentNode.parentNode.id);
                        $ionicScrollDelegate.anchorScroll(true);
                        console.log("$scope.detailText:",$scope.detailText);
                    }
                    else{
                        $scope.detailText = "CER_VIEW_LESS";
                        console.log("$scope.detailText:",$scope.detailText);
                        $scope.showingMore[boothId] = {showing: true, limit:itemList.length};
                    }
                };
                
                $scope.getLimit = function(boothId){
                    if(!$scope.isAlert){
                        if($scope.showingMore[boothId]){
                            return $scope.showingMore[boothId].limit;
                        }
                    }
                    return 3;
                }
                    
            }
        };
    });


}());
