(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folPricingOptions', function () {
        return {
            restrict: 'E',
            scope: {
                pricingData: '=',
                addProductCallback: '&',
                removeProductCallback: '&',
                editProductCallback: '&',
                edit: "="

            },
            replace: true,
            templateUrl: 'fol/directives/pricing-options/pricing-options.tpl.html',
            controller: function ($scope) {
                var getSKU = function () {
                    if ($scope.pd.skus.length === 1) {
                        return $scope.pd.skus[0].skuID;
                    } else {
                        return $scope.selectedSKU && $scope.selectedSKU.skuID;
                    }
                };

                var getSKUDescription = function(){
                    if($scope.pd.skus.length === 1){
                        return undefined;
                    }else{
                        return $scope.selectedSKU.skuTitle;
                    }
                };

                var getSelectedData = function () {
                    return {
                        skuID: getSKU(),
                        skuDescription: getSKUDescription(),
                        quantity: $scope.quantity
                    };
                };

                var addProduct = function () {
                    $scope.addProductCallback()(getSelectedData());
                };

                var editProduct = function () {
                    $scope.editProductCallback()(getSelectedData());
                };

                if ($scope.edit) {
                    $scope.quantity = $scope.pricingData.quantity || 1;
                    $scope.selectedSKU = _.find($scope.pricingData.skus, {skuID: $scope.pricingData.skuID});
                    $scope.formSubmit = editProduct;
                } else {
                    $scope.quantity = 1;
                    $scope.formSubmit = addProduct;
                }

                $scope.pd = $scope.pricingData;

                $scope.removeProduct = function () {
                    $scope.removeProductCallback()();
                };
            }
        };
    });
}());
