(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.factory('itemListSortFactory', function () {
        console.log('in ItemListSortFactory');
        var sortCallbackCreator = function (title, attribute, callbackList) {
            var cleanupActives = function () {
                //cleans up the state of all items in the callback list, setting every list item to nonselected (neither asc nor desc)
                _.each(callbackList, function (ea) {
                    ea.active = null;
                });
            };
            return {
                text: title,
                active: null,
                callback: function (items) {
                    //this item has been selected for sort, so turn off the sort flag for every other sort option
                    cleanupActives();
                    if (this.active === 'asc') {
                        //If we're in asc order, sort in desc order
                        this.active = 'desc';
                        return _.sortBy(items, attribute).reverse();
                    } else {
                        //if we're in desc order, sort in asc order.
                        this.active = 'asc';
                        return _.sortBy(items, attribute);
                    }
                }
            };
        };
        return {
            sortCallbackCreator: sortCallbackCreator
        };
    });
})();