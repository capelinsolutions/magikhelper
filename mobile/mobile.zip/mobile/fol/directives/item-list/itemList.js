(function () {
    'use strict';
    var module = angular.module('fol.mobile');

    module.directive('folItemList', function () {
        return {
            restrict: 'E',
            scope: {
                items: '=',
                sortOptions: '=',
                itemListCallback: '='
            },
            replace: true,
            templateUrl: 'fol/directives/item-list/item-list.tpl.html',
            controller: function ($scope, $ionicActionSheet, $log, $filter) {
                $scope.filterClicked = function () {
                    var translateSortOptions = function (sortOptions) {
                        _.each(sortOptions, function (each) {
                            each.text = $filter('translate')(each.text);
                        });
                        return sortOptions;
                    };
                    var hideSheet = $ionicActionSheet.show({
                        buttons: translateSortOptions($scope.sortOptions),
                        titleText: $filter('translate')('SORT'),
                        cancelText: $filter('translate')('CANCEL'),
                        cancel: function () {
                            hideSheet();
                        },
                        buttonClicked: function (index, param) {
                            $scope.items = param.callback($scope.items);
                            return true;
                        }
                    });
                };
                $scope.itemActivatedCallback = function(item){
                    $scope.itemListCallback(item);
                };
            }
        };
    });


}());
