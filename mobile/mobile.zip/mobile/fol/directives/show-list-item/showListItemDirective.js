(function() {
    "use strict";
    
    var module = angular.module("fol.mobile");

    module.directive('folShowListItem', function() {
        return {
            restrict: "E",
            scope: {
                show: "=",
                isBooth: "="
            },
            replace: true,
            template:'<ng-include src="contentUrl"> </ng-include>',
            link: function($scope) {
                $scope.$watch("isBooth",function(){
                    if($scope.isBooth){
                        $scope.contentUrl = 'fol/directives/show-list-item/show-list-item-booth.tpl.html';
                    }
                    else{
                        $scope.contentUrl = 'fol/directives/show-list-item/show-list-item.tpl.html';    
                    }
                });
            }
        };
    });

}());