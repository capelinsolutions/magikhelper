(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folProductListItem', function () {
        return {
            restrict: 'E',
            scope: {
                product: '=',
                itemActivatedCallback: '='
            },
            replace: true,
            templateUrl: 'fol/directives/product-list-item/product-list-item.tpl.html',
            controller: function ($scope, $stateParams) {
                if ($scope.product && $scope.product.uom && $scope.product.uom.toUpperCase() !== 'EA') {
                    $scope.product.price = undefined;
                }

                $scope.categoryId = $scope.product.categoryID;
                $scope.subCategoryId = $scope.product.subCategoryID;
                $scope.productId = $scope.product.productID;
                $scope.showId = $stateParams.showId;
                $scope.skuId = $scope.product.skuID;
                $scope.productTouched = function(item){
                    $scope.itemActivatedCallback(item);
                };
            }
        };
    });
}());
