(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShowStatus', function() {
        return {
            restrict: 'E',
            scope: { status: '@' },
            replace: true,
            template: '<div class="fol-show-status"><div class="show-status-bg"><div class="show-status-label">SHOW STATUS</div><div class="show-status-title">{{ ::status | translate }}</div></div></div>'
        };
    });
}());
