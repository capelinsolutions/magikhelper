(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folPricingBlock', function() {
        return {
            restrict: 'E',
            scope: { pricingData: '=' },
            replace: true,
            templateUrl: 'fol/directives/pricing-block/pricing-block.tpl.html',
            controller: function($scope) {
                $scope.viewMore = false;
                $scope.viewMoreLabel = 'PDT_VIEW_MORE';
                $scope.onViewMore = function() {
                    $scope.viewMore = !$scope.viewMore;
                    $scope.viewMoreLabel = $scope.viewMore ? 'PDT_VIEW_LESS' : 'PDT_VIEW_MORE';
                };
            }
        };
    });
}());
