(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folBoothEquipment', function() {
        return {
            restrict: 'E',
            scope: {
                cardTitle: '@',
                boothEquipment: '='
            },
            replace: true,
            templateUrl: 'fol/directives/boothEquipment/booth-equipment.tpl.html',
            controller: function($scope) {
                $scope.hasAisleCarpetColor = !_.isNull($scope.boothEquipment.aisleCarpetColor);
                $scope.hasBackDrapeColor = !_.isNull($scope.boothEquipment.backDrapeColor);
                $scope.hasSideDrapeColor = !_.isNull($scope.boothEquipment.sideDrapeColor);
                $scope.hasEquipment = $scope.hasAisleCarpetColor || $scope.hasBackDrapeColor || $scope.hasSideDrapeColor;
            }
        };
    });
}());
