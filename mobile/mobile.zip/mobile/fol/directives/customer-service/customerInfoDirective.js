(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folCustomerServiceInfo', function() {
        return {
            restrict: 'E',
            require: '^ngModel',
            scope: { customerInfo: '=ngModel' },
            replace: true,
            templateUrl: 'fol/directives/customer-service/customer-service-information.tpl.html'
        };
    });
}());
