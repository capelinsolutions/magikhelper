(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folImportantDates', function() {
        return {
            restrict: 'E',
            scope: {
                cardtitle: '@',
                eventsCollection: '=',
                maxRows: '@',
                viewAll: '&',
                showViewAll: '='
            },
            replace: true,
            templateUrl: 'fol/directives/important-dates/important-dates.tpl.html'
        };
    });
}());
