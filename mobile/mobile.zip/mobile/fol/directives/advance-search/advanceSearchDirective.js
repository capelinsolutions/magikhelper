(function() {
    "use strict";
    
    var module = angular.module("fol.mobile");

    module.directive('folAdvanceSearch', ["$state", "$stateParams", function($state, $stateParams) {
        return {
            restrict: "E",
            scope: {
                folSearchCallback: "="
            },
            replace: true,
            templateUrl: 'fol/directives/advance-search/advance-search.tpl.html',
            controller: function($scope, searchShowService, addressService){
                $scope.searchBy = 'shows';
                $scope.advance = {};
                $scope.countries = {};
                
                addressService.getCountries().then(function(countries){
                    $scope.countries = countries;
                });
                
                $scope.selectCountry = function() {
                    addressService.getStates($scope.checkout.country_code.countryCode).then(function(states) {
                        $scope.staticData.states = states;
                    });
                };
                                    
                var statesData = {};
                
                $scope.states = statesData[$scope.advance.Country];
                
                $scope.onCountryChange = function(){
                    $scope.advance.State = ""; 
                    $scope.states = [];
                    if(statesData[$scope.advance.Country] == undefined){
                        addressService.getStates($scope.advance.Country).then(function(states){
                            statesData[$scope.advance.Country] = states;
                            $scope.states = states;
                        });
                    }
                    else{
                        $scope.states = statesData[$scope.advance.Country];
                    }
                };
                
                $scope.doSearch = function(){
                    var params = $scope.advance;
                    $scope.folSearchCallback(params);
                };
            }
        };
    }]);

}());
