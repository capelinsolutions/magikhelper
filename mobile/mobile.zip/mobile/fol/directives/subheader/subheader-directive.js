(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folSubheader', function() {
        return {
            restrict: 'E',
            scope: { 
                title: '@',
                iconRight: '@'
            },
            replace: true,
            template: 
                '<div class="fol-subheader">' +
                    '<div class="bar bar-subheader bar-dark">' +
                        '<h2 class="title" translate>{{ title }}</h2>' +
                        '<button ng-if="iconRight" class="button button-small icon {{ iconRight }}"></button>' +
                    '</div>' + 
                '</div>'
        };
    });
}());
