(function () {
    'use strict';
    var module = angular.module('fol.mobile');

    module.directive('folCartTotal', function () {
        return {
            restrict: 'E',
            scope: {
                products: '=',
                parentCheckoutCallback: "=checkoutCallback"
            },
            replace: true,
            templateUrl: 'fol/directives/cart-total/cart-total.tpl.html',
            controller: function ($scope, $log) {
                $scope.total = _.reduce($scope.products, function(sum, ea){
                    return sum + (ea.price * ea.quantity);
                }, 0);
                $scope.count = $scope.products.length;
                $scope.checkoutCallback = function(){
                   $scope.parentCheckoutCallback();
                }
            }
        };
    });


}());
