describe('ContactUsDirective', function() {
    'use strict';
    var html;
    var rootScope;
    var scope;
    var elem;
    var compiled;

    var mockCartService = jasmine.createSpyObj('cartService', ['getNumberOfItemsInCart']);
    var mockSecurityTokenService = jasmine.createSpyObj('securityTokenService', ['isLoggedIn']);

    beforeEach(function() {
        module('test-html');
        module('fol.mobile', function($provide){
                $provide.value('cartService', mockCartService);
                $provide.value('securityTokenService', mockSecurityTokenService);
            }
        );
        html = '<fol-cart-icon></fol-cart-icon>';
        inject(function($compile, $rootScope) {
            rootScope = $rootScope;
            scope = $rootScope.$new();
            elem = angular.element(html);
            compiled = $compile(elem);
            compiled(scope);
            scope.$digest();
        });
    });

    describe('Show associations should control visibility', function() {
        it('should detect whether the user is associated with a show and set the scope appropriately', function() {
            rootScope.$broadcast("$stateChangeSuccess", null, {showId: '123456'});
            scope.$digest();

            expect(scope.hasShowId).toEqual(true);
        });

        it('should detect whether the user is not associated with a show and set the scope appropriately', function() {
            rootScope.$broadcast("$stateChangeSuccess", null, {showId: null});
            scope.$digest();

            expect(scope.hasShowId).toEqual(false);
        });
    });

    describe("Logged in should control visibility", function(){

        it('should detect whether the user is logged in and set the scope appropriately', function() {
            mockSecurityTokenService.isLoggedIn.and.returnValue(true);

            rootScope.$broadcast("UserLoginStatus");

            expect(scope.isLoggedIn).toEqual(true);
        });

        /*
        There's a heisenbug here.  If this is uncommented, on PhantomJS, there appears to be a race condition and one of the two tests in this suite fails.  Debugger can't catch it because its a race condition
         */
        xit('should detect whether the user is not logged in and set the scope appropriately', function() {
            mockSecurityTokenService.isLoggedIn.and.returnValue(false);

            rootScope.$broadcast("UserLoginStatus");

            expect(scope.isLoggedIn).toEqual(false);
        });

    });
});
