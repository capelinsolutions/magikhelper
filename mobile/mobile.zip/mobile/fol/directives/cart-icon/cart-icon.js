(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folCartIcon', function ($animate, $rootScope, $stateParams, cartService, securityTokenService) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'fol/directives/cart-icon/cart-icon.tpl.html',
            link: function (scope, element) {
                var animation = "bounce";

                console.log("running cart icon link");

                scope.showId = $stateParams.showId;
                scope.hasShowId = scope.showId ? true : false;

                scope.count = cartService.getNumberOfItemsInCart(scope.showId);
                $rootScope.$on('cart:updated', function () {
                    scope.count = cartService.getNumberOfItemsInCart(scope.showId);
                    if (!element.hasClass(animation)) {
                        $animate.addClass(element, animation).then(function () {
                                scope.$apply(function () {
                                    element.removeClass(animation);
                                });
                            }
                        );
                    }
                });

                $rootScope.$on("UserLoginStatus", function(){
                    scope.isLoggedIn = securityTokenService.isLoggedIn();
                    scope.count = cartService.getNumberOfItemsInCart(scope.showId);
                });

                $rootScope.$on("$stateChangeSuccess", function(){
                    scope.showId = $stateParams.showId;
                    scope.count = cartService.getNumberOfItemsInCart(scope.showId);
                    scope.hasShowId = scope.showId ? true : false;
                });
            }
        };
    });
}());
