(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShippingInfo', function() {
        return {
            restrict: 'E',
            require: '^ngModel',
            scope: { shippingContact: '=ngModel' },
            replace: true,
            templateUrl: 'fol/directives/shipping-information/shipping-information.tpl.html'
        };
    });
}());
