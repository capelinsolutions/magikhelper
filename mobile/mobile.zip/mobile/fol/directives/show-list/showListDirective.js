(function () {
    "use strict";
    
    var module = angular.module("fol.mobile");
    module.directive('folShowList',function () {
        return {
		    restrict: "E",
		    scope: {
                onViewAllClick: '&',
                formattedDate: '&',
                loadMore : '&',
                heading: '@',
                viewAll : '=',
                data: '=',
                haveMore :'=',
                isBooth: '='
		    },
		    replace: true,
		    templateUrl: 'fol/directives/show-list/show-list.tpl.html',
            link: function($scope) {
                $scope.$watch("data", function() {
                    if ($scope.data != undefined) {
                        $scope.limit = $scope.viewAll ? 4 : $scope.data.length;
                    }
                });
            },
            controller: function ($scope) {
                $scope.limit = $scope.viewAll ? 4 : $scope.data.length;
        	}
		};
    });
    
}());