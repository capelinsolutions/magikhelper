(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folOnValidSubmit', function($ionicScrollDelegate, $location, $parse) {
        return {
            require: '^form',
            restrict: 'A',
            link: function(scope, element, attrs, form) {
                form.$submitted = false;
                var fn = $parse(attrs.folOnValidSubmit);
                element.on('submit', function(event) {
                    scope.$apply(function() {
                        element.addClass('ng-submitted');
                        form.$submitted = true;
                        if (form.$valid) {
                            if (typeof fn === 'function') {
                                fn(scope, { $event: event });
                            }
                        } else {
                            var INVALID_ELEMENTS = element[0].querySelectorAll('.ng-invalid');
                            if (INVALID_ELEMENTS.length > 0) {
                                // do not scroll if id not defined
                                if (INVALID_ELEMENTS[0].parentNode.id.length > 0) {
                                    $location.hash(INVALID_ELEMENTS[0].parentNode.id);
                                    $ionicScrollDelegate.anchorScroll(true);
                                }
                            }
                        }
                    });
                });
            }
        };
    }).directive('folValidated', function() {
        return {
            restrict: 'AEC',
            require: '^form',
            link: function(scope, element, attrs, form) {
                var inputs = element.find('*');
                for (var i = 0; i < inputs.length; i++) {
                    (function(input) {
                        var attributes = input.attributes;
                            if (attributes.getNamedItem('ng-model') !== void 0 && attributes.getNamedItem('name') !== void 0) {
                            var field = form[attributes.name.value];
                                if (field !== void 0) {
                                scope.$watch(function() {
                                    return form.$submitted + '_' + field.$valid + '_' + field.$dirty;
                                }, function() {
                                    if (form.$submitted || form.$dirty) {
                                        if (!field.$valid) {
                                            element.removeClass('has-success').addClass('has-error');
                                            element.next().removeClass('ng-hide');
                                        } else {
                                            element.removeClass('has-error').addClass('has-success');
                                            element.next().addClass('ng-hide');
                                        }
                                    }
                                });
                            }
                        }
                    }(inputs[i])); //jshint ignore:line
                }
            }
        };
    }).directive('folValidPhone', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attributes, ngModel) {
                var PHONE_REGEXP = /^[1-9][0-9]{0,9}$/;
                ngModel.$validators.folValidPhone = function(modelValue) {
                    if (modelValue === undefined) {
                        return true;
                    }
                    if (PHONE_REGEXP.test(modelValue)) {
                        element.parent().removeClass('has-error').addClass('has-success');
                        return true;
                    } else {
                        element.parent().removeClass('has-success').addClass('has-error');
                        return false;
                    }
                };
            }
        };
    }).directive('folCompareTo', function() {
        return {
            require: 'ngModel',
            scope: { otherModelValue: '=folCompareTo' },
            link: function(scope, element, attributes, ngModel) {
                ngModel.$validators.folCompareTo = function(modelValue) {
                    return modelValue === scope.otherModelValue;
                };
                scope.$watch('otherModelValue', function() {
                    ngModel.$validate();
                });
            }
        };
    }).directive('folValidPhoneExt', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attributes, ngModel) {
                var PHONE_EXT_REGEXP = /^[0-9]/;
                ngModel.$validators.folValidPhone = function(modelValue) {
                    if (modelValue === undefined) {
                        return true;
                    }
                    if (PHONE_EXT_REGEXP.test(modelValue)) {
                        element.parent().removeClass('has-error').addClass('has-success');
                        return true;
                    } else {
                        element.parent().removeClass('has-success').addClass('has-error');
                        return false;
                    }
                };
            }
        };
    }).directive('folValidEmail', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elm, attrs, model) {
                var EMAIL_REGEXP = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
                var SPECIAL_REGEXP = /^[A-Za-z0-9._+-@.]+$/;
                var emailValidator = function(value) {
                    if (value === undefined) {
                        return value;
                    } else if (value.length < 5) {
                        model.$setValidity('minlength', false);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else if (value.indexOf('@') === 0 || value.indexOf('.') === 0 || value.indexOf('@') === value.length - 1 || value.indexOf('.') === value.length - 1) {
                        model.$setValidity('period_begin_end', false);
                        model.$setValidity('identifier', true);
                        model.$setValidity('minlength', true);
                        model.$setValidity('special', true);
                        model.$setValidity('email', true);
                        model.$setValidity('period', true);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else if (value.indexOf('@') < 0 || value.indexOf('.') < 0) {
                        model.$setValidity('identifier', false);
                        model.$setValidity('minlength', true);
                        model.$setValidity('special', true);
                        model.$setValidity('email', true);
                        model.$setValidity('period', true);
                        model.$setValidity('period_begin_end', true);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else if (value.indexOf('@.') > 0) {
                        model.$setValidity('period', false);
                        model.$setValidity('identifier', true);
                        model.$setValidity('minlength', true);
                        model.$setValidity('email', true);
                        model.$setValidity('special', true);
                        model.$setValidity('period_begin_end', true);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else if (!SPECIAL_REGEXP.test(value)) {
                        model.$setValidity('special', false);
                        model.$setValidity('email', true);
                        model.$setValidity('minlength', true);
                        model.$setValidity('identifier', true);
                        model.$setValidity('period', true);
                        model.$setValidity('period_begin_end', true);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else if (!EMAIL_REGEXP.test(value)) {
                        model.$setValidity('email', false);
                        model.$setValidity('minlength', true);
                        model.$setValidity('identifier', true);
                        model.$setValidity('period', true);
                        model.$setValidity('special', true);
                        model.$setValidity('period_begin_end', true);
                        elm.parent().removeClass('has-success').addClass('has-error');
                        return undefined;
                    } else {
                        model.$setValidity('email', true);
                        model.$setValidity('minlength', true);
                        model.$setValidity('identifier', true);
                        model.$setValidity('period', true);
                        model.$setValidity('special', true);
                        model.$setValidity('period_begin_end', true);
                        elm.parent().removeClass('has-error').addClass('has-success');
                        return value;
                    }
                };
                model.$parsers.push(emailValidator);
                model.$formatters.push(emailValidator);
            }
        };
    }).directive('folValidPassword', function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elm, attrs, model) {
                var NUMBER_REGEXP = /\d/;
                //                var PASSWORD_REGEXP = /(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,25})$/;
                var ALLOW_REGEXP = /^[A-Za-z0-9]+$/;
                var passwordValidator = function(value) {
                    if (value === undefined) {
                        return value;
                    } else if (value.length < 8 || value.length > 25) {
                        model.$setValidity('length', false);
                        return undefined;
                    } else if (!ALLOW_REGEXP.test(value)) {
                        model.$setValidity('numeric', true);
                        model.$setValidity('length', true);
                        model.$setValidity('special', false);
                        return undefined;
                    } else if (!NUMBER_REGEXP.test(value)) {
                        model.$setValidity('length', true);
                        model.$setValidity('special', true);
                        model.$setValidity('numeric', false);
                        return undefined;
                    } else {
                        model.$setValidity('numeric', true);
                        model.$setValidity('length', true);
                        model.$setValidity('special', true);
                        return value;
                    }
                };
                model.$parsers.push(passwordValidator);
                model.$formatters.push(passwordValidator);
            }
        };
    });
}());
