(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folImageSwipeBox', function() {
        return {
            restrict: 'E',
            scope: {
                cardtitle: '@',
                images: '='
            },
            replace: true,
            templateUrl: 'fol/directives/image-swipe-box/image-swipe-box.tpl.html'
        };
    });
}());
