(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShowHeader', function() {
        return {
            restrict: 'E',
            scope: {
                cardtitle: '@',
                headerData: '='
            },
            replace: true,
            templateUrl: 'fol/directives/show-header/show-header.tpl.html',
            link: function($scope) {
                $scope.$watch('headerData', function() {
                    if ($scope.headerData !== undefined) {
                        $scope.showDetail = $scope.headerData;
                    }
                });
            }
        };
    });
}());
