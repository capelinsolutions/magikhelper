(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShowAddressInfo', function() {
        return {
            restrict: 'E',
            replace: true,
            require: '^ngModel',
            scope: { contacts: '=ngModel' },
            templateUrl: 'fol/directives/show-address-information/show-address-information.tpl.html'
        };
    });
}());
