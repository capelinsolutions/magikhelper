(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShowList', function() {
        return {
            restrict: 'E',
            scope: {
                data: '=',
                onViewAllClick: '&',
                formattedDate: '&',
                haveMore: '=',
                loadMore: '&',
                heading: '@'
            },
            replace: true,
            templateUrl: function(elem, attrs) {
                return attrs.templateUrl || 'fol/show/show-list-view-all.tpl.html';
            },
            controller: function($scope) {
                $scope.format = function(date) {
                    return $scope.formattedDate()(date);
                };
            }
        };
    });
}());
