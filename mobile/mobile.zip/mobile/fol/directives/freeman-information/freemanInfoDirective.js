(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folFreemanInfo', function() {
        return {
            require: '^ngModel',
            scope: {
                freemanContact: '=ngModel',
                freemanAudioVisualContact: '='
            },
            restrict: 'E',
            replace: true,
            templateUrl: 'fol/directives/freeman-information/freeman-information.tpl.html'
        };
    });
}());
