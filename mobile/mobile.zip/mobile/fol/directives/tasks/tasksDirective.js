(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folTasks', function() {
        return {
            restrict: 'E',
            scope: {
                cardtitle: '@',
                tasks: '=',
                maxRows: '@',
                maxCols: '@'
            },
            replace: true,
            templateUrl: 'fol/directives/tasks/tasks-directive.tpl.html'
        };
    });
}());
