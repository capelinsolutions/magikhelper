(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folText', function() {
        return {
            restrict: 'E',
            scope: {
                cardTitle: '@',
                callToAction: '@',
                callToActionCallback: '&',
                maxLength: '@',
                cardText: '='
            },
            replace: true,
            templateUrl: 'fol/directives/text/text-directive.tpl.html',
            controller: function($scope, $sce) {
                var trimToNearestWord = function(txt, maxLength) {
                    if (maxLength > 0 && txt.length > maxLength) {
                        //trim the string to the maximum length
                        var trimmedString = txt.substr(0, maxLength);
                        //re-trim if we are in the middle of a word
                        trimmedString = trimmedString.substr(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(' ')));
                        if (trimmedString.length !== txt.length) {
                            trimmedString += '...';
                        }
                        return trimmedString;
                    } else {
                        return txt;
                    }
                };
                var text = _.unescape($scope.cardText);
                var shortenedText = trimToNearestWord(text, $scope.maxLength);
                $scope.shortenedText = $sce.trustAsHtml(shortenedText);
            }
        };
    });
}());
