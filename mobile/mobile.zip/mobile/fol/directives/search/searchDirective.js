(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folSearch', function() {
        return {
            restrict: 'E',
            scope: { folSearchCallback: '=' },
            replace: true,
            templateUrl: 'fol/directives/search/search.tpl.html',
            controller: function($scope) {
                $scope.searchForm = {};
                $scope.searchBy = 'product';
                $scope.searchQuery = '';
                $scope.doSearch = function() {
                    $scope.folSearchCallback($scope.searchQuery);
                };
                $scope.updateErrorMsg = function() {
                    $scope.errorMsg = '';
                };
            }
        };
    });
}());
