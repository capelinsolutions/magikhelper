(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folPaymentSummary', function() {
        return {
            restrict: 'E',
            scope: { paymentData: '=' },
            templateUrl: 'fol/directives/payment-summary/payment-summary.tpl.html',
            controller: function($scope) {
                $scope.products = $scope.paymentData;
            }
        };
    });
}());
