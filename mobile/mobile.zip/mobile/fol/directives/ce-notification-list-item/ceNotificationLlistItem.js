(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folCENotificationListItem', function() {
        return {
            restrict: 'E',
            scope: { 
                data: '='
            },
            replace: true,
            templateUrl: 'fol/directives/ce-notification-list-item/ce-notification-list-item.tpl.html',
            controller: function($scope, $state, ceService) {
                
                if($scope.data.issueStatus){
                    $scope.title = $scope.data.description;
                    $scope.date = $scope.data.createdDate;
                    $scope.status = $scope.data.issueStatus;
                }
                else{
                    $scope.title = $scope.data.alertTitle;
                    $scope.date = $scope.data.alertDate;
                }
                
                $scope.onItemClick = function(){
                    ceService.setSelectedNotification($scope.data);
                    $state.go("fol.ce-notification-detail");
                };
            }
        };
    });
}());
