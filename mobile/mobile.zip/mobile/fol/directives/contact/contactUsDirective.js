(function () {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folContactUs', function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                cardTitle: '@',
                cardSubheading: '@',
                data: '='
            },
            templateUrl: 'fol/directives/contact/contact-us-directive.tpl.html',
            controller: [
                '$scope',
                '$stateParams',
                'CONTACT_US_DEFAULT_PHONE',
                'CONTACT_US_DEFAULT_EMAIL',
                function ($scope, $stateParams, DEFAULT_PHONE, DEFAULT_EMAIL) {
                    $scope.phone = $scope.data.showSitePhone;
                    $scope.showState = $scope.data.showState;
                    $scope.body = encodeURI('Customer Number: ' + '\nYour Company Name: ' + '\nShow Name and City: ' + $scope.data.showName + ', ' + $scope.data.showCity + '\nBooth Number: ' + '\nPlease let Freeman Customer Support know how we can assist you:');
                    var stage = $scope.data.showStage;
                    if ($scope.data.showSitePhone && (stage === 'PRE-SHOW' || stage === 'POST-SHOW')) {
                        $scope.phone = $scope.data.showSitePhone;
                    } else {
                        $scope.phone = DEFAULT_PHONE;
                    }
                    $scope.email = DEFAULT_EMAIL;
                }
            ]
        };
    });
}());
