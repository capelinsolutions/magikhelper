(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folPhone', function() {
        return {
            restrict: 'E',
            scope: {
                phone: '=',
                title: '@'
            },
            replace: true,
            template: '<span ng-show="phone.length > 0">                 {{ ::title | translate}}             <a href="tel://{{::phone}}">                 {{::phone}}             </a>         </span>'
        };
    });
}());
