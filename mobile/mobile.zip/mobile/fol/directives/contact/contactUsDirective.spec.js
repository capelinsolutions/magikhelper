xdescribe('ContactUsDirective', function() {
    'use strict';
    var html;
    var scope;
    var elem;
    var compiled;
    beforeEach(function() {
        module('fol.mobile');
        html = '<fol-contact-us card-title=\'title\' cardSubheading=\'subHeading\' data=\'data\'></fol-contact-us>';
        inject(function($compile, $rootScope) {
            scope = $rootScope.$new();
            elem = angular.element(html);
            compiled = $compile(elem);
            compiled(scope);
            scope.$digest();
        });
    });
    describe('phone number changes based on show status, CE Show, and Help Desk Phone Number', function() {
        it('shows default phone number if it its not a CE show', function() {
            scope.data = {
                showSitePhone: '5555555555',
                showState: 'Show State',
                showName: 'Unit Test Show',
                showStage: 'PRE-SHOW'
            };
            //
            console.log(elem);
        });
    });
});
