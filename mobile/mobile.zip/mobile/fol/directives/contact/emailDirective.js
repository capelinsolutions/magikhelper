(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folEmail', function() {
        return {
            restrict: 'E',
            scope: {
                email: '=',
                body: '='
            },
            replace: true,
            template: '<span ng-show="email.length > 0">{{ ::"SFI_EMAIL" | translate}}<a href="mailto:{{::email}}?body={{::body}}">{{::email}}</a></span>'
        };
    });
}());
