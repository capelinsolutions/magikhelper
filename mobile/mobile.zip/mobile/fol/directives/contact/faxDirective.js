(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folFax', function() {
        return {
            restrict: 'E',
            scope: {
                fax: '=',
                title: '@'
            },
            replace: true,
            template: '<span ng-show="fax.length > 0">                     {{ ::title | translate}}                     {{::fax}}                 </span>'
        };
    });
}());
