(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('errSrc', function() {
        return {
            restrictions: 'A',
            link: function(scope, element, attrs) {
                element.bind('error', function() {
                    if (attrs.errSrc) {
                        element.attr('src', attrs.errSrc);
                    }
                });
            }
        };
    });
}());
