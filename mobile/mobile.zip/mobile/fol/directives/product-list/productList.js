(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folProductList', function() {
        return {
            restrict: 'E',
            scope: { products: '=' },
            replace: true,
            templateUrl: 'fol/directives/product-list/product-list.tpl.html',
            controller: function($scope) {
                console.log('in directive, product collection: ', $scope.products);
            }
        };
    });
}());
