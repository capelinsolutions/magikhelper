(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folShowRequestsStatistics', function() {
        return {
            restrict: 'E',
            scope: { 
                data: '=',
                cardTitle: '@',
                callToAction: '@',
                callToActionCallback: '&',
            },
            replace: true,
            templateUrl: 'fol/directives/show-requests-statistics/show-requests-statistics.tpl.html',
            controller: function($scope, $filter) {
                
                if($scope.data !== undefined){
                    
                    $scope.cancelled = {};
                    $scope.resolved = {};
                    $scope.open = {};

                    $scope.cancelled.count = $filter('filter')($scope.data, {issueStatus : 29}).length;
                    $scope.cancelled.text = "New";
                    
                    $scope.resolved.count = $filter('filter')($scope.data, {issueStatus : 30}).length;
                    $scope.resolved.text = "Acnknowledge";
                    
                    $scope.open.count = $filter('filter')($scope.data, {issueStatus : 31}).length;
                    $scope.open.text = "Resolved";
                }
            }
        };
    });
}());
