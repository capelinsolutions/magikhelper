(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.directive('folImageHeader', function() {
        return {
            restrict: 'E',
            scope: {
                heading: '@',
                imgSrc: '@'
            },
            replace: true,
            templateUrl: 'fol/directives/image-header/image-header.tpl.html'
        };
    });
}());
