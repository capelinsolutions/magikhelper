(function() {
    "use strict";
    
    var module = angular.module("fol.mobile");

    module.directive('folShowSearch', ["$state", "$stateParams", function($state, $stateParams) {
        return {
            restrict: "E",
            scope: {
                showBooth: "="
            },
            replace: true,

            templateUrl: 'fol/directives/show-search/show-search.tpl.html',
            controller: ["$scope", "$filter", "$state", function($scope, $filter, $state){
                $scope.search = {};
                $scope.search.searchBy = "name";
                $scope.search.searchQuery = "";
                $scope.search.searchBooth = "";
                $scope.errorMsg = "";
                $scope.search.advanceSearchText = "Advance Search ";

                var doSearchWithBooth = function () {
                    $state.go("fol.search",{
                        "searchBy" : $scope.search.searchBy,
                        "searchQuery" : $scope.search.searchQuery,
                        "searchBooth" : $scope.search.searchBooth,
                    });
                };

                $scope.doSearch = function () {
                    if($scope.showBooth){
                        console.log("booth");
                        doSearchWithBooth();
                    }
                    else{
                        
                    $state.go("fol.search",{
                        "searchBy" : $scope.search.searchBy,
                        "searchQuery" : $scope.search.searchQuery});
                    }
                };

                $scope.updateErrorMsg = function() {
                    $scope.errorMsg = "";
                 };
            }]
        };
    }]);

}());
