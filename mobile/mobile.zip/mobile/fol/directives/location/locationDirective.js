(function () {
    "use strict";
    
    var module = angular.module("fol.mobile");

    module.directive('folLocation', function () {
        return {
            restrict: "E",
            scope: {
                cardtitle: "@",
                address: "=",
                zoom: "=",
                navlabel: "@"
            },
            replace: true,

            templateUrl: 'fol/directives/location/location-directive.tpl.html',

            controller: function ($scope, $window, $ionicActionSheet, $q, $timeout, $translate, $cordovaGeolocation) {

                $scope.mapAddress = $scope.address.addressLine1 + ',' + $scope.address.addressLine2 + ',' + $scope.address.city + ',' + $scope.address.state;

                // var mapBasePathArray = [
                //     "http://maps.apple.com/?",
                //     "comgooglemaps://?"
                // ];
                var mapBasePathArray = [
                    "maps:"                    
                ];

                var createNavLink = function (index) {

                    var lat = 0;
                    var lon = 0;
                    var deferred = $q.defer();

                    $cordovaGeolocation.getCurrentPosition({timeout: 5000, enableHighAccuracy: true})
                        .then(function (position) {

                            lat = position.coords.latitude;
                            lon = position.coords.longitude;
                            var startAddress = lat.toString() + ',' + lon.toString();
                            var destAddress = $scope.mapAddress.replace(/\s/g, "+");
                            var navlink = mapBasePathArray[index] + 'saddr=' + startAddress + '&daddr=' + destAddress;
                            deferred.resolve(navlink);

                        }, function () {
                            deferred.reject({message: 'Cannot get your current location.'});
                        });

                    return deferred.promise;
                };

                $translate('LOC_GET_DIRECTIONS').then(function (translation) {
                    $scope.titleText = translation;
                });
                $translate('LOC_USE_APPLE').then(function (translation) {
                    $scope.useApple = translation;
                });
                $translate('LOC_USE_GOOGLE').then(function (translation) {
                    $scope.useGoogle = translation;
                });
                $translate('LOC_CANCEL').then(function (translation) {
                    $scope.cancelText = translation;
                });

                $scope.showNativeMap = function() {
                    var destAddress = $scope.mapAddress.replace(/\s/g, "+");
                    var navlink = mapBasePathArray[0] + 'q=' + destAddress;
                    $window.open(navlink, "_system");
                };

                // show action sheet to choose navigation app
                $scope.showNavOptions = function () {

                    if (mapBasePathArray.length === 1) {
                        createNavLink(0).then(function (navlink) {
                            $window.open(navlink, "_system");
                        }, function (err) {
                            alert(err.message, "Maps");
                        });    
                        return;                    
                    }

                    // Show the action sheet
                    var hideSheet = $ionicActionSheet.show({
                        buttons: [{
                            text: $scope.useApple
                        }, {
                            text: $scope.useGoogle
                        }],
                        titleText: $scope.titleText,
                        cancelText: $scope.cancelText,
                        cancel: function () {
                            // do nothing
                        },
                        buttonClicked: function (index) {
                            createNavLink(index).then(function (navlink) {
                                $window.open(navlink, "_system");
                            }, function (err) {
                                alert(err.message, "Maps");
                            });
                            return true;
                        }
                    });
                    // hide the sheet after five seconds
                    $timeout(function () {
                        hideSheet();
                    }, 5000);
                };
                // set address string for the map directive
                $scope.$watch("address", function () {
                    if ($scope.address !== undefined) {
                        $scope.mapAddress = $scope.address.addressLine1 + ',' + $scope.address.addressLine2 + ',' + $scope.address.city + ',' + $scope.address.state;
                    }
                });
            }
        };
    });

}());
