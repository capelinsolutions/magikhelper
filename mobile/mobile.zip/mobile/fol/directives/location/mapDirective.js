(function() {
    "use strict";
    
    var module = angular.module("fol.mobile");

    module.directive('addressBasedGoogleMap', function() {
        return {
            restrict: "A",
            scope: {
                address: "=",
                zoom: "="
            },
            replace: true,
            template: '<div class="addressMap"></div>',
            link: function($scope, elem) {

                var geocoder;
                var latlng;
                var map;
                var marker;
                var initialize = function() {
                    
                    geocoder = new google.maps.Geocoder();
                    latlng = new google.maps.LatLng(31,-97);
                    var mapOptions = {
                        zoom: $scope.zoom,
                        center: latlng,
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                        draggable: false,
                        disableDefaultUI: true,
                        disableDoubleClickZoom: true
                    };
                    map = new google.maps.Map(elem[0], mapOptions);
                };
                var markAdressToMap = function() {
                    geocoder.geocode({
                            'address': $scope.address
                        },
                        function(results, status) {
                            if (status === google.maps.GeocoderStatus.OK) {
                                map.setCenter(results[0].geometry.location);
                                marker = new google.maps.Marker({
                                    map: map,
                                    position: results[0].geometry.location
                                });
                            }
                        });
                };
                $scope.$watch("address", function() {
                    if ($scope.address !== undefined) {
                        markAdressToMap();
                    }
                });
                initialize();
            },
        };
    });

}());
