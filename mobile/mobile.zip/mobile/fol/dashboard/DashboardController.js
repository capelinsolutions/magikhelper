(function() {
    'use strict';
    var DashboardController = function($rootScope, $scope, $state, $stateParams, $http, $ionicSideMenuDelegate, $ionicHistory, securityTokenService, showService) {
        var onSuccess = function(response) {
            $rootScope.upcomingShows = response;
            if (response.length <= 0) {
                $scope.emptyList = 'We did not locate any upcoming shows for your company. Please search for your event above';
            }
        };
        $ionicHistory.clearHistory();
        var onSuccessPastShows = function(response) {
            $rootScope.pastShows = response;
        };
        var onError = function(data) {
            //TODO handle error
            data = data;
        };
        $scope.onViewAllClick = function(type) {
            $state.go('fol.shows', { 'type': type });
        };
        //Upcoming Shows
        showService.getUpcomingShows().then(onSuccess, onError);
        //Past Shows
        showService.getPastShows().then(onSuccessPastShows, onError);
        $ionicSideMenuDelegate.canDragContent(true);
    };
    var module = angular.module('fol.mobile');
    module.controller('DashboardController', [
        '$rootScope',
        '$scope',
        '$state',
        '$stateParams',
        '$http',
        '$ionicSideMenuDelegate',
        '$ionicHistory',
        'securityTokenService',
        'showService',
        DashboardController
    ]);
}());
