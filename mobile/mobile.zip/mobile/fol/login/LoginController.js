(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var LoginController = function($scope, $rootScope, $ionicHistory, $ionicSideMenuDelegate, $state, authService, securityTokenService) {
        if (securityTokenService.isLoggedIn()) {
            $state.go('fol.dashboard');
        }
        //Set Initial Values
        $ionicHistory.clearCache();
        $ionicHistory.clearHistory();
        $scope.errorMsg = '';
        $scope.username = securityTokenService.getUserName();
        $scope.password = '';
        $scope.hasFocus = false;
        $scope.rememberMe = true;
        var onAuthCompleted = function(response) {
            if ($rootScope.username !== undefined && $rootScope.username.length > 0) {
                $scope.username = $rootScope.username;
            }
            if ($rootScope.password !== undefined && $rootScope.password.length > 0) {
                $scope.password = $rootScope.password;
            }
            if (response.data === 'null') {
                $scope.errorMsg = 'The supplied Username/Password is invalid.';
            } else {
                $scope.errorMsg = '';
                securityTokenService.saveAccessToken($scope.username, response.headers('DYN_STORE_TOKEN'), response.headers('CE_TOKEN'), $scope.rememberMe);
                $rootScope.password = '';
                $rootScope.username = '';
                $ionicHistory.nextViewOptions({ disableBack: true });
                $ionicHistory.clearCache();
                $ionicHistory.clearHistory();
                $state.go('fol.dashboard');
            }
        };
        var onError = function(data) {
            if (data.status === 401) {
                $scope.errorMsg = 'The supplied Username/Password is invalid.';
            } else {
                $scope.errorMsg = 'Internal error, try again later.';
            }
        };
        $scope.doLogin = function() {
            if ($rootScope.username !== undefined && $rootScope.username !== '') {
                authService.authenticate($rootScope.username, $rootScope.password).then(onAuthCompleted, onError);
            } else {
                authService.authenticate($scope.username, $scope.password).then(onAuthCompleted, onError);
            }
        };
        $scope.updateErrorMsg = function() {
            $scope.errorMsg = '';
        };
        $ionicSideMenuDelegate.canDragContent(false);
    };
    module.controller('LoginController', [
        '$scope',
        '$rootScope',
        '$ionicHistory',
        '$ionicSideMenuDelegate',
        '$state',
        'authService',
        'securityTokenService',
        LoginController
    ]);
}());
