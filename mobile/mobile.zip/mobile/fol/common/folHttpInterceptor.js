//FOL Mobile Configuration Service
//The service will provide functionality to communicate with configuration setting
(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var folHttpInterceptor = function($injector, $q, $log, securityTokenService) {
        var request = function(config) {
            if (securityTokenService.isLoggedIn()) {
                config.headers = config.headers || {};
                config.headers.DYN_STORE_TOKEN = securityTokenService.getAccessToken();
                config.headers.CE_TOKEN = securityTokenService.getCeToken();
            }
            return config;
        };
        var requestError = function(rejection) {
            return $q.reject(rejection);
        };
        var response = function(response) {
            return response;
        };
        var responseError = function(rejection) {
            return $q.reject(rejection);
        };
        return {
            request: request,
            requestError: requestError,
            response: response,
            responseError: responseError
        };
    };
    module.factory('folHttpInterceptor', [
        '$injector',
        '$q',
        '$log',
        'securityTokenService',
        folHttpInterceptor
    ]);
    module.config(function($httpProvider) {
        $httpProvider.interceptors.push('folHttpInterceptor');
    });
}());
