/*
* Description : This class will contain the utility methods used in the application like diff betweek two dates etc.
*/
(function() {
    'use strict';
    var folCommon = function() {
        return {};
    };
    var module = angular.module('fol.mobile');
    module.factory('folCommon', [folCommon]);
}());
