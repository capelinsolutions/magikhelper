//FOL Mobile Configuration Service
//The service will provide functionality to communicate with configuration setting
(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    //dev on devices
    module.constant('StoreApiUrl', '/api/v1');
    module.constant('CONTACT_US_DEFAULT_EMAIL', 'customer.support@freemanco.com');
    module.constant('CONTACT_US_DEFAULT_PHONE', '888-508-5054');
    module.constant('DEFAULT_IMAGE', 'assets/images/no-image.jpg');
    module.config(function($ionicConfigProvider) {
        $ionicConfigProvider.backButton.text('').previousTitleText(false);
    });
    module.config(function(cfpLoadingBarProvider) {
        cfpLoadingBarProvider.includeSpinner = false;
    });
    module.service('folConfig', function($cordovaDevice) {
        this.device = $cordovaDevice.getDevice();
        this.cordova = $cordovaDevice.getCordova();
        this.model = $cordovaDevice.getModel();
        this.platform = $cordovaDevice.getPlatform();
        this.uuid = $cordovaDevice.getUUID();
        this.version = $cordovaDevice.getVersion();
    });
}());
