(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.run(function($http, DSCacheFactory) {
        DSCacheFactory('defaultCache', {
            maxAge: 60000,
            //clear data after a minute
            deleteOnExpire: 'aggressive'
        });
        $http.defaults.cache = DSCacheFactory.get('defaultCache');
    });
}());
