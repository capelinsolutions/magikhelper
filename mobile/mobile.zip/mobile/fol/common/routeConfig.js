(function () {
    'use strict';
    var app = angular.module("fol.mobile");

    app.config(function ($stateProvider, $ionicConfigProvider, $urlRouterProvider) {
        $ionicConfigProvider.backButton.text("");
        $stateProvider
            .state('fol', {
                url: "/fol",
                abstract: true,
                templateUrl: "fol/dashboard/user-layout.tpl.html",
                controller: 'FolAppController'
            })

            .state('fol.home', {
                url: "/home",
                views: {
                    'menuContent': {
                        templateUrl: "fol/home/home.tpl.html"
                    }
                }
            })

            .state('fol.search', {
                url: "/search/show/:searchBy/:searchQuery",
                views: {
                    'menuContent': {
                        templateUrl: "fol/search/show/search-show-result.tpl.html",
                        controller: 'SearchShowResultsController'
                    }
                }
            })

            .state('fol.search-show-with-booth-result', {
                url: "/search/show/:searchBy/:searchQuery/:searchBooth",
                views: {
                    'menuContent': {
                        templateUrl: "fol/search/show/search-show-with-booth-result.tpl.html",
                        controller: 'SearchShowResultsController'
                    }
                }
            })

            .state('fol.locate-company', {
                url: "/locate-company",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/locate-company.tpl.html",
                        controller: 'SearchCompanyController'
                    }
                }
            })

            .state('fol.search-company-result', {
                url: "/search-company-result/:searchQuery",
                views: {
                    'menuContent': {
                        templateUrl: "fol/search/company/search-company-result.tpl.html",
                        controller: 'SearchCompanyResultsController'
                    }
                }
            })

            .state('fol.dashboard', {
                url: "/dashboard",
                views: {
                    'menuContent': {
                        templateUrl: "fol/dashboard/dashboard.tpl.html",
                        controller: 'DashboardController'
                    }
                }
            })

            .state('fol.shows', {
                url: "/shows/:type",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-all.tpl.html",
                        controller: 'ShowViewAllController'
                    }
                }
            })

            .state('fol.show-detail', {
                url: "/show/:showId/show-detail",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-detail.tpl.html",
                        controller: 'ShowDetailController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    boothInfoService: 'boothInformationService',
                    boothInfo: function (boothInfoService, $stateParams) {
                        return boothInfoService.getBoothInformation($stateParams.showId);
                    },
                    venueAddress: function (showService, $stateParams) {
                        return showService.getVenueAddress($stateParams.showId);
                    },
                    showDates: function (showService, $stateParams) {
                        return showService.getShowDates($stateParams.showId);
                    },
                    showDetail: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    }
                }
            })
            .state('fol.booth-info', {
                url: "/show/:showId/booth-info",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/booth-information/booth-information.tpl.html",
                        controller: "BoothInfoController"
                    }
                },
                resolve: {
                    boothInfoService: 'boothInformationService',
                    showService: 'showService',
                    boothInfo: function (boothInfoService, $stateParams) {
                        return boothInfoService.getBoothInformation($stateParams.showId);
                    },
                    showInfo: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    }
                }
            })
            .state('fol.create-account', {
                url: "/account/:customerNumber/create-account",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/create-account.tpl.html",
                        controller: 'CreateAccountController'
                    }
                }
            })
            .state('fol.under-construction', {
                url: "/under-construction",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/under-construction.tpl.html"
                    }
                }
            })

            .state('fol.advanced-search', {
                url: "/show/advanced-search",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/under-construction.tpl.html"
                    }
                }
            })

            .state('fol.terms-and-condition', {
                url: "/terms-and-condition",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/terms-and-condition.tpl.html"
                    }
                }
            })

            .state('fol.forgot-username-password', {
                url: "/account/forgot-username-password/:type",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/forgot-username-password.tpl.html",
                        controller: 'ForgotUserNamePasswordController'
                    }
                }
            })
            .state('fol.forgot-username-password-result', {
                url: "/account/forgot-username-password-result/:type/:reference",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/forgot-username-password-result.tpl.html",
                        controller: 'ForgotUserNamePasswordController'
                    }
                }
            })
            .state('fol.user-confirmation', {
                url: "/account/user-confirmation",
                views: {
                    'menuContent': {
                        templateUrl: "fol/account/user-confirmation.tpl.html",
                        controller: 'LoginController'
                    }
                }
            })
            .state('fol.show-information', {
                url: "/show/:showId/show-information",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-information/show-information.tpl.html",
                        controller: 'ShowDetailController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    boothInfoService: 'boothInformationService',
                    boothInfo: function (boothInfoService, $stateParams) {
                        return boothInfoService.getBoothInformation($stateParams.showId);
                    },
                    venueAddress: function (showService, $stateParams) {
                        return showService.getVenueAddress($stateParams.showId);
                    },
                    showDates: function (showService, $stateParams) {
                        return showService.getShowDates($stateParams.showId);
                    },
                    showDetail: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    }
                }
            })
            .state('fol.contact-information', {
                url: "/show/:showId/contact-information/",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-information/contact-information/contact-information.tpl.html",
                        controller: 'ContactInformationController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    stage: function (showService, $stateParams) {
                        return showService.getShowStage($stateParams.showId);
                    }
                }
            })
            .state('fol.important-dates', {
                url: "/show/:showId/important-dates/",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-information/dates-viewAll/dates-viewall.tpl.html",
                        controller: "datesViewAllController"
                    }
                },
                resolve: {
                    showService: 'showService',
                    showDates: function (showService, $stateParams) {
                        return showService.getShowDates($stateParams.showId);
                    },
                    showDetail: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    }
                }
            })
            .state('fol.product-search', {
                url: "/show/:showId/products/search?query",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/products/products-search-result/products-search-result.tpl.html",
                        controller: "productsSearchResultController"
                    }
                },
                resolve: {
                    productService: 'productService',
                    productList: function ($stateParams, productService) {
                        return productService.getProducts($stateParams.showId, $stateParams.query);
                    }
                }

            })
            .state('fol.product-details', {
                url: "/show/:showId/category/:categoryId/subCategory/:subCategoryId/product/:productId/sku/:sku?edit",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/products/product-details/product-details.tpl.html",
                        controller: "productDetailsController"
                    }
                },
                resolve: {
                    productService: 'productService',
                    product: function ($stateParams, productService) {
                        return productService.getProduct($stateParams.showId, $stateParams.categoryId, $stateParams.subCategoryId, $stateParams.productId);
                    },

                    cartService: 'cartService',
                    cartItem: function($stateParams, cartService){
                        var item = cartService.getCartItem($stateParams.showId, $stateParams.productId, $stateParams.sku);
                        return item;
                    }
                },
                cache: false
            })
            .state('fol.shipping-address', {
                url: "/show/:showId/shipping-address",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/show-information/shipping-address.tpl.html",
                        controller: 'ContactInformationController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    stage: function (showService, $stateParams) {
                        return showService.getShowStage($stateParams.showId);
                    }
                }
            })
            .state('fol.cart', {
                url: "/show/:showId/cart",
                cache: false,
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/cart/cart.tpl.html",
                        controller: 'CartController'
                    }
                },
                resolve: {
                    cartService: 'cartService',
                    cartItems: function($stateParams, cartService){
                        return cartService.getCart($stateParams.showId);
                    }
                }
            })
            .state('fol.checkout', {
                url: "/show/:showId/checkout",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/checkout/checkout.tpl.html",
                        controller: 'CheckoutController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    userService: 'userService',
                    addressService: 'addressService',
                    cartService: 'cartService',
                    boothsList: function (showService, $stateParams) {
                        return showService.getShowBooths($stateParams.showId);
                    },
                    showDetail: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    },
                    currentUser: function(userService) {
                        return userService.getCurrentUser();
                    },
                    currentUserCompany: function(userService) {
                        return userService.getCurrentUserCompany();
                    },
                    countryList: function (addressService) {
                        return addressService.getCountries();
                    },
                    stateList: function (addressService) {
                        return addressService.getStates();
                    },
                    cartItems: function($stateParams, cartService){
                        return cartService.getCart($stateParams.showId);
                    }
                }
            })

            .state('fol.concierge-services', {
                url: "/show/:showId/concierge-services",
                views: {
                    'menuContent': {
                        templateUrl: "fol/show/concierge-services/concierge-services.tpl.html",
                        controller: 'ConciergeServicesController'
                    }
                },
                resolve: {
                    showService: 'showService',
                    showDetail: function (showService, $stateParams) {
                        return showService.getShowDetail($stateParams.showId);
                    }
                }
            });
        //Route to FOL Home - If other redirection isn't redirected.
        $urlRouterProvider.otherwise('/fol/home');
    });

    app.run(function ($rootScope) {
        $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
            console.log("An error occurred in transition\n from state: ", fromState);
            console.log("To State", toState);
            console.log("Error Message", error);
        });
    });
}());