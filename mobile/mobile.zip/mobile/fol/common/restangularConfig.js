(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.config(function(RestangularProvider, StoreApiUrl) {
        RestangularProvider.setBaseUrl(StoreApiUrl);
        RestangularProvider.setDefaultHttpFields({ cache: true });
    });
}());
