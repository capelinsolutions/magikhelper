(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    module.filter('encodeURIComponent', function() {
        return window.encodeURIComponent;
    });
}());
