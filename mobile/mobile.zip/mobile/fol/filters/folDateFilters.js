(function() {
    'use strict';
    var months = new Array(12);
    months[0] = 'JAN';
    months[1] = 'FEB';
    months[2] = 'MAR';
    months[3] = 'APR';
    months[4] = 'MAY';
    months[5] = 'JUN';
    months[6] = 'JUL';
    months[7] = 'AUG';
    months[8] = 'SEP';
    months[9] = 'OCT';
    months[10] = 'NOV';
    months[11] = 'DEC';
    var getDateFromString = function(dateString) {
        if (dateString) {
            var arr = dateString.split(/[- :T]/);
            var date = new Date(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5]);
            return date;
        }
        return null;
    };
    var getDateObjectFromString = function() {
        return function(dateString) {
            var date = getDateFromString(dateString);
            console.log('date = ', date);
            if (dateString) {
                return date;
            }
            return null;
        };
    };
    var getFormattedDateFromString = function() {
        return function(dateString) {
            var date = getDateFromString(dateString);
            if (dateString) {
                var d = date;
                //new Date(Date.parse(date));
                var month = d.getMonth();
                var day = d.getDate();
                var year = (d.getFullYear()).toString().substring(2, 4);
                if (month.length < 2) {
                    month = '0' + month;
                }
                if (day.length < 2) {
                    day = '0' + day;
                }
                var temp = month + '/' + day + '/' + year;
                return temp;
            }
            return '';
        };
    };
    var getMonthFromDateString = function() {
        return function(dateString) {
            if (dateString !== undefined) {
                var arr = dateString.split(/[- :T]/);
                var dateObj = new Date(arr[0], arr[1] - 1, arr[2]);
                return months[dateObj.getMonth()];
            } else {
                return '';
            }
        };
    };
    var module = angular.module('fol.mobile');
    module.filter('folGetFormattedDateFromString', getFormattedDateFromString);
    module.filter('folGetMonthFromDateString', getMonthFromDateString);
    module.filter('folGetDateObjectFromString', getDateObjectFromString);
}());
