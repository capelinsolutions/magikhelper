(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var createAccountService = function($http, StoreApiUrl) {
        var createAccount = function(user) {
            var url = StoreApiUrl + '/Users/CreateAccount';
            return $http.post(url, user, { headers: { 'Content-Type': 'application/json' } });
        };
        return { createAccount: createAccount };
    };
    module.factory('createAccountService', [
        '$http',
        'StoreApiUrl',
        createAccountService
    ]);
}());
