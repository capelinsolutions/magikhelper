(function() {
    'use strict';
    var forgotUsernamePasswordService = function($http, StoreApiUrl) {
        var getUsername = function(email) {
            var url = StoreApiUrl + '/Users/ForgotUserName/';
            var data = { 'email': email };
            return $http.post(url, data);
        };
        var getPassword = function(username) {
            var url = StoreApiUrl + '/Users/ForgotPassword/';
            var data = { 'login': username };
            return $http.post(url, data);
        };
        return {
            getUsername: getUsername,
            getPassword: getPassword
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('forgotUsernamePasswordService', [
        '$http',
        'StoreApiUrl',
        forgotUsernamePasswordService
    ]);
}());
