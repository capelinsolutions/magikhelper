(function() {
    'use strict';
    var CEService = function(Restangular) {
        var notification;
        var getAlerts = function(showId) {
            var show = Restangular.one('shows', showId);
            return show.getList('alerts');
        };
        var getRequests = function(showId) {
            var show = Restangular.one('shows', showId);
            return show.getList('requests');
        };
        var getSelectedNotification = function(){
            return notification;
        };
        
        var setSelectedNotification = function(notif){
            notification = notif;
        };
        
        var addRequest = function(showId, request){
            var show = Restangular.one('shows', showId).all('requests');
            return show.post(request);
        };
        return { 
            getAlerts: getAlerts,
            getRequests: getRequests,
            getSelectedNotification : getSelectedNotification,
            setSelectedNotification : setSelectedNotification,
            addRequest : addRequest
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('ceService', [
        'Restangular',
        CEService
    ]);
}());
