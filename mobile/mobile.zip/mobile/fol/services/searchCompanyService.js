(function() {
    'use strict';
    var searchCompanyService = function(Restangular) {
        var getCompaniesByName = function(name) {
            return Restangular.several('company').several('searchby').several('name').getList({ 'query': name });
        };
        return { getCompaniesByName: getCompaniesByName };
    };
    var module = angular.module('fol.mobile');
    module.factory('searchCompanyService', [
        'Restangular',
        searchCompanyService
    ]);
}());
