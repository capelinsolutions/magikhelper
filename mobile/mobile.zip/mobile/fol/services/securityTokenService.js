(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var securityTokenService = function($rootScope, localStorageService) {
        var userData = {};
        var UserData = 'user_data';
        var AccessToken = 'access_token';
        var CeToken = 'ce_token';
        var UserName = 'user_name';
        var RememberMe = 'remember_me';
        var isLoggedIn = function() {
            return userData[AccessToken] !== undefined && userData[AccessToken] !== null;
        };
        var saveAccessToken = function(username, token, cetoken, rememberMe) {
            userData[AccessToken] = token;
            userData[CeToken] = cetoken;
            userData[UserName] = username;
            userData[RememberMe] = rememberMe;
            if (rememberMe) {
                localStorageService.set(UserName, JSON.stringify(userData));
            }
            $rootScope.$broadcast('UserLoginStatus', 1);
        };
        var getAccessToken = function() {
            return userData[AccessToken];
        };
        var getCeToken = function() {
            return userData[CeToken];
        };
        // Logout From Application
        var removeAccessToken = function() {
            localStorageService.remove(UserName);
            userData[AccessToken] = null;
            if (userData[RememberMe]) {
                localStorageService.set(UserData, JSON.stringify(userData));
            } else {
                userData[UserName] = null;
            }
        };
        var logout = function() {
            removeAccessToken();
            $rootScope.$broadcast('UserLoginStatus', 0);
        };
        var getUserName = function() {
            return userData[UserName];
        };
        var isRemembered = function() {
            return userData[RememberMe];
        };
        if (localStorageService.get(UserName)) {
            userData = localStorageService.get(UserName);
            $rootScope.$broadcast('UserLoginStatus', 1);
        }
        return {
            saveAccessToken: saveAccessToken,
            removeAccessToken: removeAccessToken,
            getAccessToken: getAccessToken,
            getCeToken: getCeToken,
            isLoggedIn: isLoggedIn,
            getUserName: getUserName,
            isRemembered: isRemembered,
            logout: logout
        };
    };
    module.factory('securityTokenService', [
        '$rootScope',
        'localStorageService',
        securityTokenService
    ]);
}());
