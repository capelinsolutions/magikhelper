//FOL Mobile Show Service
//The service will provide functionality to communicate with My Show and Show Detail Services on Server side
(function() {
    'use strict';
    var searchShowService = function(Restangular) {
        var showsList = [];
        var getShowByName = function(name, booth) {
            if (booth) {
                return Restangular.several('shows').several('searchby').several('name').several('booth').getList({
                    'query': name,
                    'booth': booth
                });
            } else {
                return Restangular.several('shows').several('searchby').several('name').getList({ 'query': name });
            }
        };
        var getShowByAcronym = function(acro, booth) {
            if (booth) {
                return Restangular.several('shows').several('searchby').several('acronym').several('booth').getList({
                    'query': acro,
                    'booth': booth
                });
            } else {
                console.log('acronym search');
                return Restangular.several('shows').several('searchby').several('acronym').getList({ 'query': acro });
            }
        };
        var setShowsList = function(shows) {
            showsList = shows;
        };
        var getShowsList = function() {
            return showsList;
        };
        return {
            getShowName: getShowByName,
            getShowAcronym: getShowByAcronym,
            getShowsList: getShowsList,
            setShowsList: setShowsList
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('searchShowService', [
        'Restangular',
        searchShowService
    ]);
}());
