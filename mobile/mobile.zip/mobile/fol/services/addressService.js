//FOL Mobile Show Service
//The service will provide functionality to communicate with My Show and Show Detail Services on Server side
(function() {
    'use strict';
    var addressService = function(Restangular) {
        var _this = this;
        _this.countryId = 'USA'; // default country
        var getStates = function(countryId) {
            if (countryId) {
                _this.countryId = countryId;
            }
            else {
                countryId = getDefaultCountry();
            }
            var states = Restangular.one('countries', countryId).all('states');
            return states.getList();
        };
        var getCountries = function() {
            var countries = Restangular.all('countries');
            return countries.getList();
        };
        var getDefaultCountry = function() {
            return _this.countryId;
        };
        return {
            getStates: getStates,
            getCountries: getCountries,
            getDefaultCountry: getDefaultCountry
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('addressService', [
        'Restangular',
        '$q',
        addressService
    ]);
}());
