(function() {
    'use strict';
    var productService = function(Restangular, $q) {

        var getProduct = function(showId, categoryId, subCategoryId, productId) {
            return Restangular.one('shows', showId).one('categories', categoryId).one('subcategories', subCategoryId).one('products', productId).get();
        };
        var searchProducts = function(showId, query) {
            if (showId && query) {
                var deferred = $q.defer();
                Restangular.one('shows', showId).getList('products', { 'query': query }).then(function(products) {
                    deferred.resolve(products);
                });
                return deferred.promise;
            } else {
                return [];
            }
        };
        return {
            getProduct: getProduct,
            getProducts: searchProducts
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('productService', [
        'Restangular',
        '$q',
        productService
    ]);
}());
