(function() {
    'use strict';
    var module = angular.module('fol.mobile');
    var authService = function($http, StoreApiUrl) {
        var authenticate = function(username, password) {
            var url = StoreApiUrl + '/users/authenticate';
            var credentials = {
                'username': username,
                'password': password
            };
            return $http.post(url, credentials);
        };
        return { authenticate: authenticate };
    };
    module.factory('authService', [
        '$http',
        'StoreApiUrl',
        authService
    ]);
}());
