//FOL Mobile Show Service
//The service will provide functionality to communicate with My Show and Show Detail Services on Server side
(function() {
    'use strict';
    var checkoutService = function(Restangular) {
        var postCheckout = function(showId, checkoutData) {
            var checkout = Restangular.one('shows', showId).post('checkout', checkoutData);
            return checkout;
        };
        return {
            postCheckout: postCheckout
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('checkoutService', [
        'Restangular',
        '$q',
        checkoutService
    ]);
}());
