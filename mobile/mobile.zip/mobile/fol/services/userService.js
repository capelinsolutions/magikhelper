//FOL Mobile User Service
//The service will provide functionality to communicate with User Object Services on Server side
(function() {
    'use strict';
    var userService = function(Restangular) {
        var getCurrentUser = function() {
            var user = Restangular.one('users').one('current');
            return user.get();
        };
        var getCurrentUserCompany = function() {
            var userCompany = Restangular.one('users').one('current').one('company');
            return userCompany.get();
        };
        return {
            getCurrentUser: getCurrentUser,
            getCurrentUserCompany: getCurrentUserCompany
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('userService', ['Restangular', userService]);

}());
