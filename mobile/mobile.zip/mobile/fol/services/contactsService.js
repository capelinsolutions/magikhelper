(function() {
    'use strict';
    var contactsService = function(Restangular) {
        var getContact = function(showID) {
            var show = Restangular.one('shows', showID);
            return show.one('contacts').get();
        };
        var getFreemanContact = function(showID) {
            var show = Restangular.one('shows', showID);
            return show.one('freeman-contacts').get();
        };
        var getShippingContact = function(showID) {
            var show = Restangular.one('shows', showID);
            return show.one('shipping-contacts').get();
        };
        var getFreemanAudioVisualContact = function(showID) {
            var show = Restangular.one('shows', showID);
            return show.one('fav-contacts').get();
        };
        return {
            getContact: getContact,
            getFreemanContact: getFreemanContact,
            getShippingContact: getShippingContact,
            getFreemanAudioVisualContact: getFreemanAudioVisualContact
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('contactsService', [
        'Restangular',
        contactsService
    ]);
}());
