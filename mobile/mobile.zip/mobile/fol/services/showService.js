//FOL Mobile Show Service
//The service will provide functionality to communicate with My Show and Show Detail Services on Server side
(function() {
    'use strict';
    var showService = function(Restangular, $q) {
        var getMyShows = function() {
            var shows = Restangular.all('shows');
            return shows.getList();
        };
        var getUpcomingShows = function() {
            var shows = Restangular.all('shows').all('upcoming');
            return shows.getList();
        };
        var getPastShows = function() {
            var shows = Restangular.all('shows').all('past');
            return shows.getList();
        };
        var getShowDetail = function(showId) {
            var show = Restangular.one('shows', showId);
            return show.get();
        };
        var getShowDates = function(showId) {
            var shows = Restangular.one('shows', showId).all('dates');
            return shows.getList();
        };
        var getVenueAddress = function(showId) {
            var address = Restangular.one('shows', showId).one('venue-address');
            return address.get();
        };
        var getShowStage = function(showId) {
            var deferred = $q.defer();
            Restangular.one('shows', showId).get().then(function(show) {
                deferred.resolve(show.stage);
            });
            return deferred.promise;
        };
        var getShowBooths = function(showId) {
            var booths = Restangular.one('shows', showId).all('booths');
            return booths.getList();
        };
        return {
            getMyShows: getMyShows,
            getUpcomingShows: getUpcomingShows,
            getPastShows: getPastShows,
            getShowDetail: getShowDetail,
            getShowDates: getShowDates,
            getVenueAddress: getVenueAddress,
            getShowStage: getShowStage,
            getShowBooths: getShowBooths
        };
    };
    var module = angular.module('fol.mobile');
    module.factory('showService', [
        'Restangular',
        '$q',
        showService
    ]);
}());
