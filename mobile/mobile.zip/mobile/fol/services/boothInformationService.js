(function() {
    'use strict';
    var BoothInformationService = function(Restangular) {
        var getBoothInformation = function(showId) {
            var show = Restangular.one('shows', showId);
            return show.one('booth-information').get();
        };
        return { getBoothInformation: getBoothInformation };
    };
    var module = angular.module('fol.mobile');
    module.factory('boothInformationService', [
        'Restangular',
        BoothInformationService
    ]);
}());
