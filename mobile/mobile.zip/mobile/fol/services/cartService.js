(function () {
    "use strict";
    var module = angular.module("fol.mobile");
    module.factory('cartService', function ($stateParams, $rootScope, localStorageService, $log) {
        var cartName = function(showId){
            return "cart-"+showId;
        };

        var updateCart = function(showId, cartProduct, skuID){
            var cart = getCart(showId);
            var model = generateModel(cartProduct);
            if(skuID) {
                //edit the model to use hte OLD sku ID for lookup
                model.skuID = skuID;
            }
            console.log('finding product to update wiht model', model);
            var idx = _.findIndex(cart, model);
            console.log("found product to update", cart, idx);
            cart[idx] = cartProduct;
            console.log("edited product: ", cart[idx]);
            saveCart(showId, cart);
        };

        function saveCart(showId, cart) {
            var name = cartName(showId);
            var cartString = JSON.stringify(cart);

            localStorageService.set(name, cartString);
            $rootScope.$broadcast('cart:updated');
        }

        function generateModel(cartProduct) {
            var model;

            if (cartProduct.skuID) {
                model = {
                    productID: cartProduct.productID,
                    categoryID: cartProduct.categoryID,
                    subCategoryID: cartProduct.subCategoryID,
                    skuID: cartProduct.skuID
                };
            } else {
                model = {
                    productID: cartProduct.productID,
                    categoryID: cartProduct.categoryID,
                    subCategoryID: cartProduct.subCategoryID
                };
            }
            return model;
        }

        var addToCart = function (showId, cartProduct) {
            var cart = getCart(showId);

            var model = generateModel(cartProduct);

            var idx = _.findIndex(cart, model);
            if (idx !== -1) {
                $log.info('found a duplicate item in cart', cartProduct);
                cart[idx].quantity += cartProduct.quantity;
            } else {
                cart.push(cartProduct);
            }
            saveCart(showId, cart);
        };

        var getCart = function (showId) {
            var cart = localStorageService.get(cartName(showId));
            if(!cart){
                cart = [];
            }
            return cart;
        };

        var getCartItem = function(showId, productId, skuId){
            var cart = getCart(showId);
            var product;
            if(skuId) {
                product = cart[_.findIndex(cart, {productID: productId, skuID: skuId})];
            }else{
                product = cart[_.findIndex(cart, {productID: productId})];
            }
            return product;
        };

        var getNumberOfItemsInCart = function (showId) {
            var cart = getCart(showId);
            return cart.length;
        };

        var removeFromCart = function(showId, productId, skuId){
            console.log("remove from cart: ", showId, productId, skuId);
            var cart = getCart(showId);
            if(skuId) {
                _.remove(cart, {productID: productId, skuID: skuId});
            }else{
                _.remove(cart, {productID: productId});
            }
            saveCart(showId, cart);
        };

        var clearCart = function(showId){
            localStorageService.remove(cartName(showId));
            $rootScope.$broadcast('cart:updated');
        };

        return {
            addToCart: addToCart,
            updateCart: updateCart,
            getCart: getCart,
            getCartItem: getCartItem,
            getNumberOfItemsInCart: getNumberOfItemsInCart,
            removeFromCart: removeFromCart,
            clearCart: clearCart
        };
    });
})();
